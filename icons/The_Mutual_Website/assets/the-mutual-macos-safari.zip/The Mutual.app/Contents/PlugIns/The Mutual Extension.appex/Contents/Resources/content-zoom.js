/**
 * The Mutual - Zoom Caption Observer (Safari Edition)
 * Captures live captions from Zoom Web App and provides one-click Side Panel toggle.
 */

(function () {
  console.log("[The Mutual Safari] Zoom content script initialized.");

  let lastText = "";
  let observer = null;

  function injectBadge() {
    if (document.getElementById("the-mutual-badge")) return;

    const badge = document.createElement("div");
    badge.id = "the-mutual-badge";
    badge.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="width:7px;height:7px;border-radius:50%;background:#2D6A4F;display:inline-block;box-shadow:0 0 6px rgba(45,106,79,0.4);"></span>
        <span style="font-weight:600;color:#1C1917;letter-spacing:0.02em;">The Mutual</span>
        <span style="color:#78716C;font-size:11px;">• Monitoring Alignment (Zoom • ⌥M to toggle)</span>
      </div>
    `;
    Object.assign(badge.style, {
      position: "fixed", top: "16px", left: "16px", zIndex: "99999",
      background: "rgba(255,255,255,0.94)", backdropFilter: "blur(8px)",
      border: "1px solid rgba(0,0,0,0.08)", borderRadius: "20px",
      padding: "6px 14px", boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
      fontFamily: "system-ui,-apple-system,sans-serif", fontSize: "12px",
      color: "#292524", userSelect: "none", cursor: "pointer"
    });

    badge.title = "Click or press Option+M to toggle The Mutual alignment panel.";
    badge.addEventListener("click", () => {
      if (window.theMutualToggleDrawer) window.theMutualToggleDrawer();
    });

    document.body && document.body.appendChild(badge);
  }

  function sendCaption(text, speaker) {
    text = text.trim();
    if (!text || text.length < 5 || text === lastText) return;
    lastText = text;

    try {
      chrome.runtime.sendMessage({
        type: "CAPTIONS_CHUNK",
        payload: {
          speaker: speaker || "Participant",
          text: text,
          source: "zoom",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
        }
      });
    } catch (e) {}
  }

  function attachObserver() {
    if (observer) return;

    const SELECTORS = [
      ".live-transcription-subtitle",
      "[class*='ClosedCaption']",
      "[class*='caption-text']",
      "[aria-label*='Caption']",
      ".subtitle-section"
    ];

    observer = new MutationObserver(() => {
      for (const sel of SELECTORS) {
        const els = document.querySelectorAll(sel);
        els.forEach(el => {
          const text = el.innerText || el.textContent || "";
          const colonIdx = text.indexOf(":");
          let speaker = "Participant", body = text;
          if (colonIdx > 0 && colonIdx < 40) {
            speaker = text.slice(0, colonIdx).trim();
            body = text.slice(colonIdx + 1).trim();
          }
          sendCaption(body, speaker);
        });
      }
    });

    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function init() {
    injectBadge();
    attachObserver();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  setInterval(injectBadge, 5000);
})();
