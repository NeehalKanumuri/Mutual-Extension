/**
 * The Mutual - Google Meet Real-Time Caption Observer (Safari Edition)
 * Captures live captions from Google Meet and provides one-click Side Panel toggle.
 */

(function () {
  console.log("[The Mutual Safari] Google Meet content script initialized.");

  let lastCapturedSentence = "";
  let lastSpeaker = "Speaker";
  let observer = null;

  // Insert subtle non-intrusive status badge into Meet UI
  function injectStatusBadge() {
    if (document.getElementById("the-mutual-meet-badge")) return;

    const badge = document.createElement("div");
    badge.id = "the-mutual-meet-badge";
    badge.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px;">
        <span style="width:7px; height:7px; border-radius:50%; background:#2D6A4F; display:inline-block; box-shadow:0 0 6px rgba(45,106,79,0.4);"></span>
        <span style="font-weight:600; color:#1C1917; letter-spacing:0.02em;">The Mutual</span>
        <span style="color:#78716C; font-size:11px;">• Monitoring Alignment (⌥M to toggle panel)</span>
      </div>
    `;

    Object.assign(badge.style, {
      position: "fixed",
      top: "16px",
      left: "16px",
      zIndex: "99999",
      background: "rgba(255, 255, 255, 0.94)",
      backdropFilter: "blur(8px)",
      border: "1px solid rgba(0, 0, 0, 0.08)",
      borderRadius: "20px",
      padding: "6px 14px",
      boxShadow: "0 2px 10px rgba(0, 0, 0, 0.04)",
      fontFamily: "system-ui, -apple-system, sans-serif",
      fontSize: "12px",
      color: "#292524",
      userSelect: "none",
      transition: "opacity 0.2s ease, transform 0.15s ease",
      cursor: "pointer"
    });

    badge.title = "The Mutual is monitoring delegation clarity. Click or press ⌥M to toggle side panel.";
    badge.addEventListener("click", () => {
      if (window.theMutualToggleDrawer) {
        window.theMutualToggleDrawer();
      }
    });

    document.body.appendChild(badge);
  }

  // Observe captions
  function initCaptionObserver() {
    if (observer) return;

    const CAPTION_CONTAINER_SELECTORS = [
      "div[jsname='r4nke']",
      "div[jscontroller='bCDE4b']",
      ".a4bIc",
      "div[aria-live='polite']",
      "div[aria-live='assertive']",
      ".iTTPOb"
    ];

    observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (!mutation.addedNodes.length) continue;

        for (const node of mutation.addedNodes) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;

          let captionText = "";
          let speaker = "Speaker";

          const textEl = node.querySelector ? (node.querySelector(".a4bIc") || node.querySelector("span[jsname]")) : null;
          if (textEl) {
            captionText = textEl.innerText || textEl.textContent || "";
          } else if (node.innerText) {
            captionText = node.innerText;
          }

          const speakerEl = node.closest ? node.closest("[jscontroller]")?.querySelector(".zs75td") : null;
          if (speakerEl) {
            speaker = speakerEl.innerText || "Speaker";
          }

          captionText = captionText.trim();

          if (captionText && captionText.length > 8 && captionText !== lastCapturedSentence) {
            if (captionText.includes(" ") && !captionText.endsWith("...")) {
              lastCapturedSentence = captionText;
              lastSpeaker = speaker;

              const payload = {
                speaker: speaker,
                text: captionText,
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
              };

              try {
                chrome.runtime.sendMessage({
                  type: "CAPTIONS_CHUNK",
                  payload: payload
                });
              } catch (e) {}
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });

    console.log("[The Mutual Safari] Caption mutation observer attached.");
  }

  function checkReady() {
    injectStatusBadge();
    initCaptionObserver();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", checkReady);
  } else {
    checkReady();
  }

  setInterval(injectStatusBadge, 4000);
})();
