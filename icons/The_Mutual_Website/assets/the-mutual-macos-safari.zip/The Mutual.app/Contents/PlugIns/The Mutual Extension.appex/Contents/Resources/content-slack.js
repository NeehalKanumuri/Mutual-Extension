/**
 * The Mutual - Slack Huddle Observer (Safari Edition)
 * Captures live captions from Slack Huddles and provides one-click Side Panel toggle.
 */

(function () {
  console.log("[The Mutual Safari] Slack content script initialized.");

  let lastText = "";
  let observer = null;

  function injectBadge() {
    if (document.getElementById("the-mutual-badge")) return;

    const badge = document.createElement("div");
    badge.id = "the-mutual-badge";
    badge.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="width:7px;height:7px;border-radius:50%;background:#2D6A4F;display:inline-block;box-shadow:0 0 6px rgba(45,106,79,0.4);"></span>
        <span style="font-weight:600;color:#1C1917;letter-spacing:0.02em;">The Mutual</span>
        <span style="color:#78716C;font-size:11px;">• Monitoring Alignment (Slack • ⌥M to toggle)</span>
      </div>
    `;
    Object.assign(badge.style, {
      position: "fixed", top: "16px", left: "16px", zIndex: "99999",
      background: "rgba(255,255,255,0.94)", backdropFilter: "blur(8px)",
      border: "1px solid rgba(0,0,0,0.08)", borderRadius: "20px",
      padding: "6px 14px", boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
      fontFamily: "system-ui,-apple-system,sans-serif", fontSize: "12px",
      color: "#292524", userSelect: "none", cursor: "pointer"
    });

    badge.title = "Click or press Option+M to toggle The Mutual alignment panel.";
    badge.addEventListener("click", () => {
      if (window.theMutualToggleDrawer) window.theMutualToggleDrawer();
    });

    document.body && document.body.appendChild(badge);
  }

  const IGNORED_PHRASES = [
    "looking to create a workspace",
    "create a new workspace",
    "workspace instead",
    "sign in to",
    "slack connect"
  ];

  function sendCaption(text, speaker) {
    text = text.trim();
    if (!text || text.length < 5 || text === lastText) return;
    const lower = text.toLowerCase();
    if (IGNORED_PHRASES.some(phrase => lower.includes(phrase))) return;
    lastText = text;

    try {
      chrome.runtime.sendMessage({
        type: "CAPTIONS_CHUNK",
        payload: {
          speaker: speaker || "Huddle Participant",
          text: text,
          source: "slack",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
        }
      });
    } catch (e) {}
  }

  function attachObserver() {
    if (observer) return;

    const SELECTORS = [
      "[data-qa='huddle_caption']",
      "[class*='huddle_caption']",
      ".p-huddle-closed-caption",
      ".p-huddle-transcript",
      "[data-qa='caption_text']",
      ".c-huddle__caption-text"
    ];

    observer = new MutationObserver(() => {
      for (const sel of SELECTORS) {
        document.querySelectorAll(sel).forEach(el => {
          const text = el.innerText || el.textContent || "";
          if (text.trim().length > 5) {
            sendCaption(text, "Slack Participant");
          }
        });
      }
    });

    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function init() {
    injectBadge();
    attachObserver();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  setInterval(injectBadge, 5000);
})();
