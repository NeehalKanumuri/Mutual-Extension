/**
 * The Mutual — Application Logic & State Machine
 * Handles:
 * - Real-time Caption Interception & Simulation
 * - Psychological Safety Script Generation
 * - Micro Contract Studio with Mutual Sign Off
 * - Preflight Deliverable Auditing
 * - Full offline / standalone fallback resilience
 */

// Application State
const state = {
  backendUrl: "http://localhost:8000",
  geminiKey: "",
  micAuthorized: false,
  isServerConnected: false,
  activeScenarioId: "scenario_executive_deck",
  scenarios: [],
  simulationInterval: null,
  simulationIndex: 0,
  capturedTranscript: [],
  interceptorFlags: [],
  currentContract: null,
  employeeSigned: false,
  managerSigned: false,
  activePersona: "neehal",
  audioEnabled: true,
  isSimulating: false,
  simulationTimeout: null,
  sampleDeliverables: {}
};

// Embedded Fallback Scenarios in case backend is loading
const FALLBACK_SCENARIOS = [
  {
    id: "scenario_executive_deck",
    title: "The Bangalore Executive Sync (Bellandur Tech Park)",
    role: "Marcus (VP Operations) delegating to Product Lead",
    description: "Quintessential Bangalore tech park delegation: high power-distance, casual colloquialisms ('do one thing', 'pakka', 'sometime next week only'), and creeping scope.",
    dialogue_stream: [
      { speaker: "Marcus (VP)", timestamp: "00:04", text: "Hey boss, thanks for jumping on a quick sync. What's the scene with our Q4 pilot rollout?" },
      { speaker: "Marcus (VP)", timestamp: "00:12", text: "Do one thing: sometime next week only, put together a clean deck for the leadership review." },
      { speaker: "Marcus (VP)", timestamp: "00:21", text: "Make sure it looks pakka professional, give it some proper polish so it pops, boss." },
      { speaker: "Marcus (VP)", timestamp: "00:30", text: "Also, just touch upon international pricing and throw in a few competitor benchmarks if you can, adjust maadi." },
      { speaker: "Marcus (VP)", timestamp: "00:41", text: "Loop in whoever from the Outer Ring Road sales team needs to see it, and ping me off-line once it's in good shape. Pakka?" }
    ],
    full_transcript: "Marcus (VP): Hey boss, thanks for jumping on a quick sync. What's the scene with our Q4 pilot rollout? Do one thing: sometime next week only, put together a clean deck for the leadership review. Make sure it looks pakka professional, give it some proper polish so it pops, boss. Also, just touch upon international pricing and throw in a few competitor benchmarks if you can, adjust maadi. Loop in whoever from the Outer Ring Road sales team needs to see it, and ping me off-line once it's in good shape. Pakka?",
    sample_deliverables: {
      strong: "# Q4 Pilot Rollout Executive Presentation\n\n**Format**: 5-Slide Google Slides deck built on Executive Brand Template 2026.\n**Status**: Draft for Wednesday 3:00 PM Review | Designated Approver: Marcus (VP)\n\n### Summary of Contents & Definition of Done:\n1. Slide 1 - Executive Summary: Core pilot KPIs and 42% retention uplift.\n2. Slide 2 - Top 3 Churn Risks: Granular breakdown of enterprise friction.\n3. Slide 3 - 90-Day Expansion Roadmap: Concrete milestones.\n4. Slide 4 - Key Domestic Competitor Benchmarks: 3-point parity comparison.\n5. Slide 5 - Immediate Decision Framework: Budget sign-off.\n\n### Out-of-Scope Boundaries:\nNote: International pricing modeling and live video captures have been explicitly excluded from this deck as agreed in our delegation handshake.\n\n### Approvals:\nElena (Head of Enterprise Sales) has reviewed Slide 4 data points.",
      flawed: "# Some Thoughts on Q4\n\nHere is a quick draft of what we discussed.\nWe looked at churn and it seems okay. We also added 12 pages on international EMEA pricing strategies and spent 3 days researching Asian market tax laws. Still waiting to hear from everyone on the sales team to see if they like the colors."
    }
  },
  {
    id: "scenario_feature_spec",
    title: "The Undefined Feature Spec (Engineering Misalignment)",
    dialogue_stream: [
      { speaker: "Rhea (PM)", timestamp: "00:03", text: "Hey team, we need a spec for the refreshed customer checkout flow." },
      { speaker: "Rhea (PM)", timestamp: "00:11", text: "Send me something whenever you get a chance, maybe a quick write-up." },
      { speaker: "Rhea (PM)", timestamp: "00:19", text: "Just touch on payment gateway options and do your magic on the error handling." },
      { speaker: "Rhea (PM)", timestamp: "00:28", text: "Check with the team to make sure everyone is cool with it before Friday." }
    ],
    full_transcript: "Rhea (PM): Hey team, we need a spec for the refreshed customer checkout flow. Send me something whenever you get a chance, maybe a quick write-up. Just touch on payment gateway options and do your magic on the error handling. Check with the team to make sure everyone is cool with it before Friday.",
    sample_deliverables: {
      strong: "# RFC-402: Refreshed Customer Checkout Flow Architecture\n\n**Author**: Tech Lead | **Primary Approvers**: Rhea (PM), Dave (Staff Architect)\n**Review Cutoff**: Friday 4:00 PM EST\n\n## 1. Scope & Deliverable Format\n2-Page architectural specification covering API interaction and state machine transitions.\n\n## 2. Definition of Done Checklist\n- [x] Payment Gateway Evaluation: Comprehensive matrix between Stripe Elements and Adyen Drop-in.\n- [x] Robust Error Handling: Automated exponential backoff for HTTP 402/503 errors.\n- [x] Latency Benchmark: Architecture verified to maintain < 250ms roundtrip payload.\n\n## 3. Explicit Anti-Goals (Out of Scope)\nCryptocurrency settlement and cross-border currency conversions are strictly excluded for V1 as agreed in the Micro Contract.",
      flawed: "Here's the checkout stuff. We built a full blockchain smart contract prototype because we felt like exploring it. Didn't write down error handling yet. Let us know what you think sometime."
    }
  }
];

// Fallback Behavioral Rule Matrix
const CLIENT_VAGUENESS_RULES = [
  {
    pattern: /(sometime next week( only)?|sometime soon|asap|as soon as possible|whenever you get (to it|a chance)|by end of week)/i,
    category: "Temporal Ambiguity",
    risk: "High",
    diagnosis: "Temporal Ambiguity creates divergent mental deadlines. Superiors assume early completion; subordinates prioritize other tasks, leading to perceived contract breach.",
    script: "To ensure I protect focus time for this, should I aim to have this draft in your inbox before Wednesday morning, or is Friday EOD the hard cutoff?"
  },
  {
    pattern: /(make it look (pakka )?(professional|clean|nice|pretty)|make it pop|give it some (proper )?polish|high production value|do your magic)/i,
    category: "Subjective Quality Metric",
    risk: "High",
    diagnosis: "Aesthetic subjectivity causes excessive rework. What looks 'clean' to an IC often lacks the executive framing expected by leadership.",
    script: "When you say 'make it look pakka professional', is there a specific existing deck or template from our team that represents the exact bar you have in mind?"
  },
  {
    pattern: /(just touch (on|upon)|throw in a few|maybe add some|keep it high level but detailed|and whatever else|adjust maadi)/i,
    category: "Scope Creep Hazard",
    risk: "Medium",
    diagnosis: "Boundary erosion. The manager treats additions as zero-cost afterthoughts, ballooning employee workload and delaying primary delivery.",
    script: "Understood. Should we treat that as a strict requirement for V1, or should I list it as an optional Phase 2 appendix item if time permits?"
  },
  {
    pattern: /(send me something|put together a quick (deck|one-pager|doc|write-up)|shoot me a note|give me a breakdown)/i,
    category: "Undefined Deliverable Format",
    risk: "Medium",
    diagnosis: "Format misalignment. Delivering a 10-page doc when a 3-bullet email was expected wastes hours; delivering a brief note when slides were needed causes credibility loss.",
    script: "To tailor this for the right audience: are you looking for an informal 3-bullet Slack recap, or a formal slide presentation for stakeholder review?"
  },
  {
    pattern: /(loop in whoever|check with the team|run it by folks|get buy-in from people|align with everyone|ping me off-line|take it off-line)/i,
    category: "Diffuse Accountability",
    risk: "High",
    diagnosis: "The Organizational Bystander Effect. Unspecified stakeholders either stall progress through committee paralysis or ignore review requests completely.",
    script: "Who holds final veto power on this before we ship? I'll schedule a targeted 15-minute review specifically with them."
  }
];

// Initialize on DOM load
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initPersona();
  initStorage();
  initTabs();
  initDrawerAndSubviews();
  initSimulator();
  initHandshake();
  initPreflight();
  initSettings();
  checkBackendHealth();
  listenToExtensionEvents();
});

// Load stored settings
function initStorage() {
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["backendUrl", "geminiKey", "micAuthorized", "session_transcript"], (res) => {
      if (res.backendUrl) state.backendUrl = res.backendUrl;
      if (res.geminiKey) state.geminiKey = res.geminiKey;
      if (res.micAuthorized) state.micAuthorized = true;
      const urlInput = document.getElementById("setting-backend-url");
      const keyInput = document.getElementById("setting-gemini-key");
      if (urlInput) urlInput.value = state.backendUrl;
      if (keyInput) keyInput.value = state.geminiKey;

      // Restore session captions if present and transcript is currently empty, filtering junk
      if (res.session_transcript && Array.isArray(res.session_transcript)) {
        const clean = res.session_transcript.filter((item) => {
          if (!item || !item.text) return false;
          const t = item.text.toLowerCase();
          return !t.includes("looking to create a workspace") &&
                 !t.includes("create a new workspace") &&
                 !t.includes("workspace instead");
        });
        // Purge permanently if dirty
        if (clean.length !== res.session_transcript.length) {
          chrome.storage.local.set({ session_transcript: clean });
        }
        if (state.capturedTranscript.length === 0 && clean.length > 0) {
          clean.forEach((item) => {
            state.capturedTranscript.push(item);
            appendTranscriptLine(item.speaker || "Participant", item.text, item.timestamp || "", false);
          });
          const cntEl = document.getElementById("transcript-count");
          if (cntEl) cntEl.innerText = `${state.capturedTranscript.length} lines captured`;
        }
      }
    });
  } else {
    state.backendUrl = localStorage.getItem("mutual_backend_url") || "http://localhost:8000";
    state.geminiKey = localStorage.getItem("mutual_gemini_key") || "";
    const urlInput = document.getElementById("setting-backend-url");
    const keyInput = document.getElementById("setting-gemini-key");
    if (urlInput) urlInput.value = state.backendUrl;
    if (keyInput) keyInput.value = state.geminiKey;
  }

  // Load and apply profile
  const savedName = localStorage.getItem("mutual_user_name") || "Kanumuri Neehal";
  const savedRole = localStorage.getItem("mutual_user_role") || "Product & Engineering Lead";
  const savedEmail = localStorage.getItem("mutual_user_email") || "kanumurineehal@gmail.com";
  const savedManager = localStorage.getItem("mutual_user_manager") || "Marcus (VP Operations)";
  const drawerName = document.getElementById("drawer-user-name");
  const drawerRole = document.getElementById("drawer-user-role");
  const drawerAvatar = document.getElementById("drawer-user-avatar");
  const headingName = document.getElementById("profile-name-heading");
  const drawerAuthSub = document.getElementById("drawer-auth-sub");
  const inputName = document.getElementById("profile-input-name");
  const inputRole = document.getElementById("profile-input-role");
  const inputEmail = document.getElementById("profile-input-email");
  const inputManager = document.getElementById("profile-input-manager");

  if (drawerName) drawerName.innerText = savedName;
  if (drawerRole) drawerRole.innerText = savedRole;
  if (headingName) headingName.innerText = savedName;
  if (drawerAuthSub) drawerAuthSub.innerText = savedEmail;
  if (inputName) inputName.value = savedName;
  if (inputRole) inputRole.value = savedRole;
  if (inputEmail) inputEmail.value = savedEmail;
  if (inputManager) inputManager.value = savedManager;
  if (drawerAvatar) {
    const initials = savedName.split(" ").map(p => p[0]).join("").toUpperCase().slice(0, 2);
    drawerAvatar.innerText = initials || "KN";
  }
}

// Navigation Tabs
function initTabs() {
  const tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");
      tabBtns.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach((pane) => pane.classList.remove("active"));

      btn.classList.add("active");
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add("active");
    });
  });

  // Flow shortcut buttons
  const topHandshakeBtn = document.getElementById("btn-goto-handshake");
  if (topHandshakeBtn) {
    topHandshakeBtn.addEventListener("click", () => {
      if (state.capturedTranscript && state.capturedTranscript.length > 0) {
        handleUserSubmitAndProceed();
      } else {
        const tabBtn = document.querySelector("[data-tab='tab-handshake']");
        if (tabBtn) tabBtn.click();
      }
    });
  }

  document.getElementById("btn-goto-preflight").addEventListener("click", () => {
    document.querySelector("[data-tab='tab-preflight']").click();
  });
}

// ============================================================================
// Appearance & Theme Management (Light, Dark, System)
// ============================================================================

function initTheme() {
  const savedTheme = localStorage.getItem("mutual_theme") || "system";
  applyTheme(savedTheme);

  document.querySelectorAll(".theme-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const val = btn.getAttribute("data-theme-val");
      if (val) {
        applyTheme(val);
        localStorage.setItem("mutual_theme", val);
        showToast(`Theme set to ${val}`);
      }
    });
  });

  if (window.matchMedia) {
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
      const current = localStorage.getItem("mutual_theme") || "system";
      if (current === "system") {
        applyTheme("system");
      }
    });
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  document.querySelectorAll(".theme-btn").forEach((b) => {
    b.classList.toggle("active", b.getAttribute("data-theme-val") === theme);
  });
}

// ============================================================================
// Persona Perspectives (Neehal - Employee POV vs Bhushith - Manager POV)
// ============================================================================

const PERSONAS = {
  neehal: {
    id: "neehal",
    name: "Neehal",
    role: "Employee (Executor)",
    shortRole: "Employee",
    initials: "KN",
    email: "kanumurineehal@gmail.com",
    counterpartId: "bhushith",
    counterpartName: "Bhushith",
    counterpartRole: "Manager (Delegator)"
  },
  bhushith: {
    id: "bhushith",
    name: "Bhushith",
    role: "Manager (Delegator)",
    shortRole: "Manager",
    initials: "BM",
    email: "bhushith@themutual.ai",
    counterpartId: "neehal",
    counterpartName: "Neehal",
    counterpartRole: "Employee (Executor)"
  }
};

function initPersona() {
  state.activePersona = localStorage.getItem("mutual_active_persona") || "neehal";

  const btnNeehal = document.getElementById("persona-btn-neehal");
  const btnBhushith = document.getElementById("persona-btn-bhushith");
  const btnQuickSwitch = document.getElementById("btn-quick-switch-persona");
  const btnActiveSign = document.getElementById("btn-active-persona-sign");

  if (btnNeehal) {
    btnNeehal.addEventListener("click", () => setPersona("neehal"));
  }
  if (btnBhushith) {
    btnBhushith.addEventListener("click", () => setPersona("bhushith"));
  }
  if (btnQuickSwitch) {
    btnQuickSwitch.addEventListener("click", () => {
      const next = state.activePersona === "neehal" ? "bhushith" : "neehal";
      setPersona(next);
    });
  }

  setPersona(state.activePersona);
}

function setPersona(personaId) {
  state.activePersona = personaId;
  localStorage.setItem("mutual_active_persona", personaId);

  const btnNeehal = document.getElementById("persona-btn-neehal");
  const btnBhushith = document.getElementById("persona-btn-bhushith");
  if (btnNeehal) btnNeehal.classList.toggle("active", personaId === "neehal");
  if (btnBhushith) btnBhushith.classList.toggle("active", personaId === "bhushith");

  const quickInput = document.getElementById("quick-input-text");
  if (quickInput) {
    if (personaId === "neehal") {
      quickInput.placeholder = "e.g. Bhushith: Put together a clean 5-slide deck for Wednesday...";
    } else {
      quickInput.placeholder = "e.g. Neehal: Draft is ready, focusing on key retention KPIs...";
    }
  }

  const p = PERSONAS[personaId];
  if (p) {
    const drawerName = document.getElementById("drawer-user-name");
    const drawerRole = document.getElementById("drawer-user-role");
    const drawerAvatar = document.getElementById("drawer-user-avatar");
    if (drawerName) drawerName.innerText = p.name;
    if (drawerRole) drawerRole.innerText = p.role;
    if (drawerAvatar) drawerAvatar.innerText = p.initials;
  }

  updateApprovalUI();
}

// ============================================================================
// Hamburger Menu & Sub-View Overlays (Settings, Profile, Auth, Theory, Terms, Privacy)
// ============================================================================

function initDrawerAndSubviews() {
  const btnHamburger = document.getElementById("btn-hamburger");
  const drawerBackdrop = document.getElementById("drawer-backdrop");
  const drawerMenu = document.getElementById("drawer-menu");
  const btnCloseDrawer = document.getElementById("btn-close-drawer");

  const openDrawer = () => {
    if (drawerBackdrop) drawerBackdrop.classList.add("active");
    if (drawerMenu) {
      drawerMenu.classList.add("active");
      drawerMenu.setAttribute("aria-hidden", "false");
    }
  };

  const closeDrawer = () => {
    if (drawerBackdrop) drawerBackdrop.classList.remove("active");
    if (drawerMenu) {
      drawerMenu.classList.remove("active");
      drawerMenu.setAttribute("aria-hidden", "true");
    }
  };

  if (btnHamburger) btnHamburger.addEventListener("click", openDrawer);
  if (btnCloseDrawer) btnCloseDrawer.addEventListener("click", closeDrawer);
  if (drawerBackdrop) drawerBackdrop.addEventListener("click", closeDrawer);

  // Subview navigation: Settings, Profile, Auth, Theory, Terms, Privacy
  const subviews = {
    "open-settings": "view-settings",
    "open-profile": "view-profile",
    "open-auth": "view-auth",
    "open-theory": "view-theory",
    "open-terms": "view-terms",
    "open-privacy": "view-privacy"
  };

  const openSubview = (viewId) => {
    closeDrawer();
    document.querySelectorAll(".subview-container").forEach((v) => v.classList.remove("active"));
    const targetView = document.getElementById(viewId);
    if (targetView) {
      targetView.classList.add("active");
      targetView.scrollTop = 0;
    }
  };

  const closeAllSubviews = () => {
    document.querySelectorAll(".subview-container").forEach((v) => v.classList.remove("active"));
  };

  // Drawer menu items click handler
  document.querySelectorAll(".drawer-item[data-action]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const action = btn.getAttribute("data-action");
      if (subviews[action]) {
        openSubview(subviews[action]);
      }
    });
  });

  // Back to workspace & close buttons in subviews
  document.querySelectorAll("[data-action='close-subview']").forEach((btn) => {
    btn.addEventListener("click", closeAllSubviews);
  });

  // ESC key to close drawer or subview
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      const activeSubview = document.querySelector(".subview-container.active");
      if (activeSubview) {
        closeAllSubviews();
      } else if (drawerMenu && drawerMenu.classList.contains("active")) {
        closeDrawer();
      }
    }
  });

  // Taskbar Top button inside Settings
  const btnMenubarSettings = document.getElementById("btn-menubar-trigger-settings");
  if (btnMenubarSettings) {
    btnMenubarSettings.addEventListener("click", async () => {
      try {
        const res = await fetch(`${state.backendUrl}/api/whisper/launch-menubar`, { method: "POST" });
        if (res.ok) {
          showToast("Whisper active in macOS top taskbar.");
        }
      } catch (e) {
        showToast("Local Whisper engine running at http://localhost:8000");
      }
    });
  }

  // Toggle API Key visibility
  const btnToggleKey = document.getElementById("btn-toggle-key-visibility");
  const keyInput = document.getElementById("setting-gemini-key");
  if (btnToggleKey && keyInput) {
    btnToggleKey.addEventListener("click", () => {
      const isPwd = keyInput.type === "password";
      keyInput.type = isPwd ? "text" : "password";
      btnToggleKey.innerText = isPwd ? "Hide Key" : "Show Key";
    });
  }

  // Profile saving & persistence
  const btnSaveProfile = document.getElementById("btn-save-profile");
  if (btnSaveProfile) {
    btnSaveProfile.addEventListener("click", () => {
      const name = document.getElementById("profile-input-name").value.trim() || "Kanumuri Neehal";
      const email = document.getElementById("profile-input-email").value.trim() || "kanumurineehal@gmail.com";
      const role = document.getElementById("profile-input-role").value.trim() || "Product & Engineering Lead";
      const manager = document.getElementById("profile-input-manager").value.trim() || "Marcus (VP Operations)";

      localStorage.setItem("mutual_user_name", name);
      localStorage.setItem("mutual_user_email", email);
      localStorage.setItem("mutual_user_role", role);
      localStorage.setItem("mutual_user_manager", manager);

      // Update UI elements
      const drawerName = document.getElementById("drawer-user-name");
      const drawerRole = document.getElementById("drawer-user-role");
      const drawerAvatar = document.getElementById("drawer-user-avatar");
      const headingName = document.getElementById("profile-name-heading");
      const drawerAuthSub = document.getElementById("drawer-auth-sub");

      if (drawerName) drawerName.innerText = name;
      if (drawerRole) drawerRole.innerText = role;
      if (headingName) headingName.innerText = name;
      if (drawerAuthSub) drawerAuthSub.innerText = email;
      if (drawerAvatar) {
        const initials = name.split(" ").map(p => p[0]).join("").toUpperCase().slice(0, 2);
        drawerAvatar.innerText = initials || "KN";
      }

      showToast("Profile changes saved successfully.");
    });
  }

  // Auth / Logout toggle
  const btnToggleLogout = document.getElementById("btn-toggle-logout");
  const authStatusBadge = document.getElementById("auth-status-badge");
  const drawerStatus = document.getElementById("drawer-user-status");
  const authUserEmail = document.getElementById("auth-user-email");
  let isAuthenticated = true;

  if (btnToggleLogout) {
    btnToggleLogout.addEventListener("click", () => {
      isAuthenticated = !isAuthenticated;
      if (isAuthenticated) {
        btnToggleLogout.innerText = "Sign Out";
        btnToggleLogout.style.background = "#991B1B";
        if (authStatusBadge) {
          authStatusBadge.innerText = "Authenticated";
          authStatusBadge.className = "badge badge-sage";
        }
        if (drawerStatus) {
          drawerStatus.innerText = "Active";
          drawerStatus.style.background = "var(--sage-bg)";
          drawerStatus.style.color = "var(--sage-text)";
        }
        showToast("Signed in as kanumurineehal@gmail.com");
      } else {
        btnToggleLogout.innerText = "Sign In Again";
        btnToggleLogout.style.background = "var(--sage-accent)";
        if (authStatusBadge) {
          authStatusBadge.innerText = "Signed Out";
          authStatusBadge.className = "badge badge-amber";
        }
        if (drawerStatus) {
          drawerStatus.innerText = "Signed Out";
          drawerStatus.style.background = "var(--amber-bg)";
          drawerStatus.style.color = "var(--amber-text)";
        }
        showToast("Signed out of active workspace session.");
      }
    });
  }

  const btnSwitchAcc = document.getElementById("btn-switch-account");
  if (btnSwitchAcc) {
    btnSwitchAcc.addEventListener("click", () => {
      const newEmail = prompt("Enter new work email to switch accounts:", "neehal@themutual.ai");
      if (newEmail && newEmail.trim()) {
        if (authUserEmail) authUserEmail.innerText = newEmail.trim();
        const drawerAuthSub = document.getElementById("drawer-auth-sub");
        if (drawerAuthSub) drawerAuthSub.innerText = newEmail.trim();
        showToast(`Switched account to ${newEmail.trim()}`);
      }
    });
  }

  // Single Sign-On buttons
  const btnSsoGoogle = document.getElementById("btn-sso-google");
  const btnSsoSlack = document.getElementById("btn-sso-slack");
  if (btnSsoGoogle) {
    btnSsoGoogle.addEventListener("click", () => {
      showToast("Authenticated via Google Workspace SSO.");
    });
  }
  if (btnSsoSlack) {
    btnSsoSlack.addEventListener("click", () => {
      showToast("Connected with Slack Workspace.");
    });
  }
}

// Health Check
async function checkBackendHealth() {
  const dot = document.getElementById("server-status-dot");
  const text = document.getElementById("server-status-text");

  try {
    const res = await fetch(`${state.backendUrl}/api/health`, { method: "GET" });
    if (res.ok) {
      const data = await res.json();
      state.isServerConnected = true;
      if (dot) dot.className = "status-dot";
      if (text) text.innerText = "";
      loadScenariosFromBackend();
      return;
    }
  } catch (e) {
    // Backend offline; use embedded engine
  }

  state.isServerConnected = false;
  if (dot) dot.className = "status-dot amber";
  if (text) text.innerText = "";
  state.scenarios = FALLBACK_SCENARIOS;
  populateScenarioDropdown(state.scenarios);
}

async function loadScenariosFromBackend() {
  try {
    const res = await fetch(`${state.backendUrl}/api/scenarios`);
    if (res.ok) {
      const data = await res.json();
      state.scenarios = data.scenarios || FALLBACK_SCENARIOS;
      populateScenarioDropdown(state.scenarios);
      return;
    }
  } catch (e) {
    state.scenarios = FALLBACK_SCENARIOS;
  }
  populateScenarioDropdown(state.scenarios);
}

function populateScenarioDropdown(scenarios) {
  const selector = document.getElementById("scenario-selector");
  selector.innerHTML = "";
  scenarios.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = `Simulation: ${s.title}`;
    selector.appendChild(opt);
  });

  const liveOpt = document.createElement("option");
  liveOpt.value = "live_meet";
  liveOpt.textContent = "Live Google Meet Captions Stream";
  selector.appendChild(liveOpt);

  // Default sample deliverables
  if (scenarios[0] && scenarios[0].sample_deliverables) {
    state.sampleDeliverables = scenarios[0].sample_deliverables;
  }
}

// ============================================================================
// TAB 1: Simulator & Interceptor Engine
// ============================================================================

// ============================================================================
// TAB 1: Simulator & Interceptor Engine
// ============================================================================

// Web Speech Synthesis & Chime Audio Engine
function speakLine(text, onEnded) {
  if (!state.audioEnabled || typeof window === "undefined" || !window.speechSynthesis) {
    setTimeout(onEnded, 2400);
    return;
  }

  try {
    window.speechSynthesis.cancel();

    // Signal parent window to animate audio equalizer
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: "SPEAKING_STATUS", isSpeaking: true }, "*");
    }

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Prioritize natural Indian English voices if available on machine
    const voices = window.speechSynthesis.getVoices();
    const inVoice = voices.find((v) => 
      v.lang === "en-IN" || 
      v.lang.startsWith("en-IN") || 
      v.name.includes("India") || 
      v.name.includes("Rishi") || 
      v.name.includes("Veena")
    );
    if (inVoice) {
      utterance.voice = inVoice;
    }
    utterance.rate = 1.05; // brisk Bangalore tech sync cadence
    utterance.pitch = 1.0;

    let hasEnded = false;
    const finish = () => {
      if (hasEnded) return;
      hasEnded = true;
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: "SPEAKING_STATUS", isSpeaking: false }, "*");
      }
      onEnded();
    };

    utterance.onend = finish;
    utterance.onerror = finish;

    // Safety fallback timeout in case browser TTS event hangs
    const maxDuration = Math.max(text.length * 85, 3200);
    setTimeout(() => {
      if (!hasEnded) finish();
    }, maxDuration);

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn("[The Mutual] SpeechSynthesis error:", err);
    setTimeout(onEnded, 2200);
  }
}

function playInterventionChime() {
  if (!state.audioEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sine";
    // Dual frequency harmonic ping (D5 -> A5)
    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);

    gain.gain.setValueAtTime(0.06, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.32);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.32);
  } catch (e) {}
}

// ============================================================================
// Live Microphone — Offscreen Bridge (Chrome MV3 Side Panel Safe)
// ============================================================================
// The Chrome Side Panel context cannot call getUserMedia or SpeechRecognition
// directly — Chrome blocks it silently (DOMException / not-allowed).
//
// Solution: We use the Chrome Offscreen API.
//   background.js creates an offscreen document (offscreen.html / offscreen.js)
//   that DOES have microphone permission. That document runs SpeechRecognition
//   and relays results back via chrome.runtime.sendMessage.
//
// Message flow:
//   sidepanel  →  chrome.runtime.sendMessage({ type: "START_MIC" })
//   background →  ensureOffscreen() → sends { type: "START_RECOGNITION", target: "offscreen" }
//   offscreen  →  SpeechRecognition → relays { type: "SPEECH_RESULT" }
//   background →  forwards to all contexts (side panel receives it in listenToExtensionEvents)
// ============================================================================

function toggleLiveMicrophone() {
  if (state.isLiveMicListening) {
    stopLiveMicrophone();
  } else {
    startLiveMicrophone();
  }
}

function openPermissionTab() {
  if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
    const permUrl = chrome.runtime.getURL("permission.html");
    if (chrome.tabs.query) {
      chrome.tabs.query({ url: permUrl }, (tabs) => {
        if (tabs && tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, { active: true });
        } else {
          chrome.tabs.create({ url: permUrl });
        }
      });
    } else {
      chrome.tabs.create({ url: permUrl });
    }
  } else {
    window.open("permission.html", "_blank");
  }
}

function startSynthwaveAudioVisualizer(stream) {}
function stopSynthwaveAudioVisualizer() {}

async function startLiveMicrophone() {
  const btnText = document.getElementById("live-mic-btn-text");
  const desc    = document.getElementById("mic-status-description");

  if (desc)    desc.innerText    = "";
  if (btnText) btnText.innerText = "Connecting…";

  // Check if running in Safari or environment without chrome.offscreen
  const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || (typeof chrome === "undefined" || !chrome.offscreen);

  if (isSafari) {
    // Safari / Web Companion: Run SpeechRecognition directly!
    startDirectSpeechRecognition();
    return;
  }

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
    // Chrome: Ask background service worker to use offscreen bridge
    chrome.runtime.sendMessage({ type: "START_MIC", lang: "en-IN" }, (response) => {
      if (chrome.runtime.lastError) {
        console.warn("[The Mutual] START_MIC error:", chrome.runtime.lastError.message);
        startDirectSpeechRecognition();
      }
    });
  } else {
    startDirectSpeechRecognition();
  }
}

function stopLiveMicrophone() {
  state.isLiveMicListening = false;
  stopSynthwaveAudioVisualizer();

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: "STOP_MIC" }).catch(() => {});
  }
  if (state._directRecognition) {
    try { state._directRecognition.stop(); } catch(e) {}
    state._directRecognition = null;
  }
  updateMicStoppedUI();
  showToast("Microphone listening stopped.");
}

// Called when offscreen or direct speech sends SPEECH_RESULT, SPEECH_ERROR, SPEECH_STATUS back
function handleSpeechResult(transcript, isFinal) {
  if (isFinal) {
    const cleaned = transcript.trim();
    if (cleaned.length > 3) {
      const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      processIncomingLine("You (Live Mic)", cleaned, timestamp);
    }
  } else {
    const interimBox = document.getElementById("live-interim-box");
    if (interimBox && transcript.trim()) {
      interimBox.style.display = "block";
      interimBox.innerHTML = `<strong>Live Speech:</strong> <em>"${escapeHtml(transcript)}"</em>`;
    }
  }
}

function handleSpeechStarted() {
  state.isLiveMicListening = true;

  const idleControls = document.getElementById("mic-idle-controls");
  const activeControls = document.getElementById("mic-active-controls");
  const desc = document.getElementById("mic-status-description");
  const dot = document.getElementById("mic-status-dot");

  if (idleControls) idleControls.style.display = "none";
  if (activeControls) activeControls.style.display = "flex";

  if (dot) dot.className = "pulse-dot-green";
  if (desc) desc.innerText = "";
  const emptyState = document.getElementById("transcript-empty-state");
  if (emptyState) emptyState.innerText = "Listening to live microphone… Speak or conduct your meeting.";

  // Play audio wave video inside the button
  const waveVid = document.getElementById("audiowave-video");
  if (waveVid) {
    try {
      waveVid.currentTime = 0;
      waveVid.play().catch(() => {});
    } catch (e) {}
  }
}

function handleSpeechError(error) {
  const desc = document.getElementById("mic-status-description");
  console.warn("[The Mutual] Speech error:", error);

  if (error === "not-allowed" || error === "service-not-allowed") {
    state.micAuthorized = false;
    stopLiveMicrophone();
    if (desc) desc.innerText = "Microphone access needed. Check the opened permission tab…";
    showToast("Microphone authorization needed. Please click Allow in the opened tab.");
    openPermissionTab();
  } else if (error === "not-supported") {
    if (desc) desc.innerText = "Web Speech API not supported in this engine.";
    showToast("Speech Recognition not supported.");
  }
  // no-speech / aborted are normal — auto-restarts
}

// ── Direct engine (Safari, Web Companion, Fallback) ──────────────────────────

function startDirectSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showToast("Speech Recognition not supported in this browser.");
    updateMicStoppedUI();
    return;
  }

  // Pre-request getUserMedia to ensure macOS / Safari permission prompt appears & hook synthwave visualizer
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ audio: true })
      .then((stream) => {
        console.log("[The Mutual] Safari mic permission confirmed.");
        startSynthwaveAudioVisualizer(stream);
      })
      .catch((err) => {
        console.warn("[The Mutual] Safari getUserMedia notice:", err);
      });
  }

  const desc = document.getElementById("mic-status-description");
  const rec = new SpeechRecognition();
  rec.continuous      = true;
  rec.interimResults  = true;
  rec.lang            = "en-IN";

  rec.onstart  = handleSpeechStarted;
  rec.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      handleSpeechResult(event.results[i][0].transcript, event.results[i].isFinal);
    }
  };
  rec.onerror = (event) => handleSpeechError(event.error);
  rec.onend   = () => {
    if (state.isLiveMicListening) {
      try { rec.start(); } catch(e) {}
    } else {
      updateMicStoppedUI();
    }
  };

  state._directRecognition = rec;
  try {
    rec.start();
  } catch (e) {
    console.warn("[The Mutual] Direct SpeechRecognition start error:", e);
  }
}

function updateMicStoppedUI() {
  state.isLiveMicListening = false;
  stopSynthwaveAudioVisualizer();

  const waveVid = document.getElementById("audiowave-video");
  if (waveVid) {
    try {
      waveVid.pause();
      waveVid.currentTime = 0;
    } catch (e) {}
  }

  const idleControls = document.getElementById("mic-idle-controls");
  const activeControls = document.getElementById("mic-active-controls");
  const btn = document.getElementById("btn-toggle-live-mic");
  const btnText = document.getElementById("live-mic-btn-text");
  const desc = document.getElementById("mic-status-description");
  const dot = document.getElementById("mic-status-dot");
  const interimBox = document.getElementById("live-interim-box");
  const submitCard = document.getElementById("submit-proceed-card");
  const linesBadge = document.getElementById("submit-lines-badge");
  const topHandshakeBtn = document.getElementById("btn-goto-handshake");

  if (activeControls) activeControls.style.display = "none";
  if (idleControls) idleControls.style.display = "flex";

  if (btn) {
    btn.className = "btn btn-primary btn-sm";
    btn.style.background = "";
  }
  if (btnText) btnText.innerText = "Start Live Listening";
  if (dot) dot.className = "status-dot";
  if (desc) desc.innerText = "";
  if (interimBox) interimBox.style.display = "none";

  // Show prominent Submit & Proceed card if transcript lines have been captured
  if (state.capturedTranscript && state.capturedTranscript.length > 0) {
    if (submitCard) submitCard.style.display = "block";
    if (linesBadge) linesBadge.innerText = `${state.capturedTranscript.length} lines ready`;
    if (topHandshakeBtn) {
      topHandshakeBtn.innerHTML = `Submit & Proceed →`;
      topHandshakeBtn.style.background = "var(--sage-accent)";
      topHandshakeBtn.style.color = "#FFFFFF";
      topHandshakeBtn.style.fontWeight = "600";
    }
  } else {
    if (submitCard) submitCard.style.display = "none";
    if (topHandshakeBtn) {
      topHandshakeBtn.innerText = "Handshake →";
      topHandshakeBtn.style.background = "";
      topHandshakeBtn.style.color = "";
      topHandshakeBtn.style.fontWeight = "";
    }
  }
}

async function handleUserSubmitAndProceed() {
  const fullText = state.capturedTranscript.map((t) => `${t.speaker}: ${t.text}`).join(" ");
  if (!fullText || fullText.trim().length === 0) {
    showToast("No transcript captured yet. Start listening or add text first.");
    return;
  }

  // Stop active mic or simulation if running
  if (state.isLiveMicListening) {
    stopLiveMicrophone();
  }
  if (state.isSimulating) {
    stopSimulation();
  }

  const btn = document.getElementById("btn-submit-proceed");
  const btnText = document.getElementById("submit-proceed-text");
  const btnIcon = document.getElementById("submit-proceed-icon");
  const origText = btnText ? btnText.innerText : "Submit Briefing & Run AI Analysis →";

  // Visual loading feedback
  if (btn) btn.disabled = true;
  if (btnIcon) btnIcon.innerText = "";
  if (btnText) btnText.innerText = "AI Processing Briefing & Synthesizing Contract…";
  showToast("Submitting transcript to AI behavioral engine...");

  try {
    // 1. Run interceptor analysis on complete text if backend connected
    if (state.isServerConnected) {
      try {
        const interceptRes = await fetch(`${state.backendUrl}/api/intercept`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: fullText,
            context: fullText,
            api_key: state.geminiKey
          })
        });
        if (interceptRes.ok) {
          const analysis = await interceptRes.json();
          if (analysis.flags && analysis.flags.length > 0) {
            analysis.flags.forEach((flag) => {
              if (!state.interceptorFlags.some((f) => f.detected_phrase === flag.detected_phrase)) {
                renderAlertCard(flag, flag.detected_phrase || fullText);
              }
            });
          }
        }
      } catch (err) {
        console.warn("[The Mutual] Full transcript intercept error:", err);
      }
    }

    // 2. Synthesize Micro Contract
    await generateContractFromTranscript();

    // 3. Switch to Handshake Tab (Tab 2)
    const handshakeTab = document.querySelector("[data-tab='tab-handshake']");
    if (handshakeTab) {
      handshakeTab.click();
    }

    showToast("Micro Contract synthesized. Both parties can now sign below.");
  } catch (e) {
    console.error("[The Mutual] Submit error:", e);
    showToast("Synthesis error. Switched to Handshake with local draft.");
    const handshakeTab = document.querySelector("[data-tab='tab-handshake']");
    if (handshakeTab) handshakeTab.click();
  } finally {
    if (btn) btn.disabled = false;
    if (btnIcon) btnIcon.innerText = "";
    if (btnText) btnText.innerText = origText;
  }
}

function initSimulator() {
  // Mode switcher tabs
  const btnModeLive = document.getElementById("btn-mode-live");
  const btnModeSim = document.getElementById("btn-mode-sim");
  const panelLive = document.getElementById("panel-live-mic");
  const panelSim = document.getElementById("panel-simulation");

  if (btnModeLive && btnModeSim && panelLive && panelSim) {
    btnModeLive.addEventListener("click", () => {
      btnModeLive.classList.add("active");
      btnModeSim.classList.remove("active");
      panelLive.style.display = "block";
      panelSim.style.display = "none";
    });

    btnModeSim.addEventListener("click", () => {
      btnModeSim.classList.add("active");
      btnModeLive.classList.remove("active");
      panelSim.style.display = "flex";
      panelLive.style.display = "none";
    });
  }

  // Live Microphone trigger button
  const btnToggleLiveMic = document.getElementById("btn-toggle-live-mic");
  if (btnToggleLiveMic) {
    btnToggleLiveMic.addEventListener("click", toggleLiveMicrophone);
  }

  // Red Stop Recording button
  const btnStopLiveMic = document.getElementById("btn-stop-live-mic");
  if (btnStopLiveMic) {
    btnStopLiveMic.addEventListener("click", stopLiveMicrophone);
  }

  // Audio wave video button (clicking it stops recording)
  const btnListeningWave = document.getElementById("btn-listening-wave");
  if (btnListeningWave) {
    btnListeningWave.addEventListener("click", stopLiveMicrophone);
  }

  // Active handshake button
  const btnGotoHandshakeActive = document.getElementById("btn-goto-handshake-active");
  if (btnGotoHandshakeActive) {
    btnGotoHandshakeActive.addEventListener("click", () => {
      const hBtn = document.getElementById("btn-goto-handshake");
      if (hBtn) hBtn.click();
    });
  }

  // Clear feed in active state
  const btnClearFeedActive = document.getElementById("btn-clear-feed-active");
  if (btnClearFeedActive) {
    btnClearFeedActive.addEventListener("click", () => {
      const clearBtn = document.getElementById("btn-clear-feed");
      if (clearBtn) clearBtn.click();
    });
  }

  // Quick text briefing input
  const btnToggleQuick = document.getElementById("btn-toggle-quick-input");
  const quickContainer = document.getElementById("quick-input-container");
  const btnSubmitQuick = document.getElementById("btn-submit-quick-text");
  const quickTextarea = document.getElementById("quick-input-text");

  if (btnToggleQuick && quickContainer) {
    btnToggleQuick.addEventListener("click", () => {
      const isHidden = quickContainer.style.display === "none" || !quickContainer.style.display;
      quickContainer.style.display = isHidden ? "flex" : "none";
      btnToggleQuick.innerText = isHidden ? "− Hide" : "+ Add Text";
      if (isHidden && quickTextarea) quickTextarea.focus();
    });
  }

  if (btnSubmitQuick && quickTextarea) {
    btnSubmitQuick.addEventListener("click", () => {
      const val = quickTextarea.value.trim();
      if (!val) return;

      let speaker = "Manager";
      let body = val;
      if (val.includes(":")) {
        const parts = val.split(":");
        speaker = parts[0].trim();
        body = parts.slice(1).join(":").trim();
      }

      const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      processIncomingLine(speaker, body, timestamp);
      quickTextarea.value = "";
      const submitCard = document.getElementById("submit-proceed-card");
      const linesBadge = document.getElementById("submit-lines-badge");
      const topHandshakeBtn = document.getElementById("btn-goto-handshake");
      if (submitCard) submitCard.style.display = "block";
      if (linesBadge) linesBadge.innerText = `${state.capturedTranscript.length} lines ready`;
      if (topHandshakeBtn) {
        topHandshakeBtn.innerHTML = `Submit & Proceed →`;
        topHandshakeBtn.style.background = "var(--sage-accent)";
        topHandshakeBtn.style.color = "#FFFFFF";
        topHandshakeBtn.style.fontWeight = "600";
      }
      showToast("Briefing added to transcript. Interceptor analyzing...");
    });
  }

  // Menubar Top Trigger
  const btnMenubarTrigger = document.getElementById("btn-menubar-trigger");
  if (btnMenubarTrigger) {
    btnMenubarTrigger.addEventListener("click", async () => {
      try {
        const res = await fetch(`${state.backendUrl}/api/whisper/launch-menubar`, { method: "POST" });
        if (res.ok) {
          showToast("The Mutual active in macOS top taskbar.");
        }
      } catch (e) {
        showToast("Whisper engine active on http://localhost:8000");
      }
    });
  }

  // Simulation controls
  const btnStart = document.getElementById("btn-start-sim");
  const btnPause = document.getElementById("btn-pause-sim");
  const btnClear = document.getElementById("btn-clear-feed");
  const btnClearSim = document.getElementById("btn-clear-sim-feed");
  const btnAudio = document.getElementById("btn-audio-toggle");
  const selector = document.getElementById("scenario-selector");
  const btnGotoSim = document.getElementById("btn-goto-handshake-sim");
  const btnSubmitProceed = document.getElementById("btn-submit-proceed");

  if (btnSubmitProceed) {
    btnSubmitProceed.addEventListener("click", () => {
      handleUserSubmitAndProceed();
    });
  }

  if (btnGotoSim) {
    btnGotoSim.addEventListener("click", () => {
      if (state.capturedTranscript && state.capturedTranscript.length > 0) {
        handleUserSubmitAndProceed();
      } else {
        const tabBtn = document.querySelector("[data-tab='tab-handshake']");
        if (tabBtn) tabBtn.click();
      }
    });
  }

  if (btnAudio) {
    btnAudio.addEventListener("click", () => {
      state.audioEnabled = !state.audioEnabled;
      btnAudio.innerText = state.audioEnabled ? "Voice: On" : "Voice: Off";
      showToast(state.audioEnabled ? "Simulation voice enabled" : "Simulation voice muted");
    });
  }

  if (selector) {
    selector.addEventListener("change", () => {
      state.activeScenarioId = selector.value;
      const selected = state.scenarios.find((s) => s.id === selector.value);
      if (selected && selected.sample_deliverables) {
        state.sampleDeliverables = selected.sample_deliverables;
      }
      stopSimulation();
    });
  }

  if (btnStart) {
    btnStart.addEventListener("click", () => {
      startSimulation();
    });
  }

  if (btnPause) {
    btnPause.addEventListener("click", () => {
      stopSimulation();
    });
  }

  const clearHandler = () => {
    stopSimulation();
    if (state.isLiveMicListening) {
      stopLiveMicrophone();
    }
    state.capturedTranscript = [];
    state.interceptorFlags = [];
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ session_transcript: [] });
    }
    document.getElementById("transcript-feed").innerHTML = `
      <div id="transcript-empty-state" style="color:var(--text-muted); font-style:italic; padding:12px; text-align:center;">
        Transcript cleared.
      </div>
      <div id="live-interim-box" class="interim-speech-preview" style="display:none;"></div>
    `;
    document.getElementById("alerts-container").innerHTML = "";
    document.getElementById("alert-counter").innerText = "0";
    document.getElementById("transcript-count").innerText = "0 lines captured";

    const submitCard = document.getElementById("submit-proceed-card");
    if (submitCard) submitCard.style.display = "none";
    const topHandshakeBtn = document.getElementById("btn-goto-handshake");
    if (topHandshakeBtn) {
      topHandshakeBtn.innerText = "Handshake →";
      topHandshakeBtn.style.background = "";
      topHandshakeBtn.style.color = "";
      topHandshakeBtn.style.fontWeight = "";
    }
  };

  if (btnClear) btnClear.addEventListener("click", clearHandler);
  if (btnClearSim) btnClearSim.addEventListener("click", clearHandler);
}

function startSimulation() {
  // Always ensure Tab 1 (Interceptor) is active so user sees live output
  const tabBtn = document.querySelector("[data-tab='tab-interceptor']");
  if (tabBtn && !tabBtn.classList.contains("active")) {
    tabBtn.click();
  }

  const currentScenario = state.scenarios.find((s) => s.id === state.activeScenarioId) || state.scenarios[0];
  if (!currentScenario) return;

  const btnStart = document.getElementById("btn-start-sim");
  const btnPause = document.getElementById("btn-pause-sim");
  btnStart.style.display = "none";
  btnPause.style.display = "inline-flex";

  const stream = currentScenario.dialogue_stream || [];
  if (state.simulationIndex >= stream.length) {
    state.simulationIndex = 0;
  }

  // Prevent multiple intervals or timeouts running concurrently
  state.isSimulating = true;
  if (state.simulationTimeout) {
    clearTimeout(state.simulationTimeout);
    state.simulationTimeout = null;
  }
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }

  const playNextLine = async () => {
    if (!state.isSimulating) return;

    if (state.simulationIndex >= stream.length) {
      stopSimulation();
      showToast("Simulation complete. Click 'Create Handshake' to lock in alignment.");
      return;
    }

    const item = stream[state.simulationIndex];
    state.simulationIndex++;
    await processIncomingLine(item.speaker, item.text, item.timestamp);

    // Speak line with SpeechSynthesis, then advance after natural pause
    speakLine(item.text, () => {
      if (!state.isSimulating) return;
      state.simulationTimeout = setTimeout(playNextLine, 800);
    });
  };

  // Play first line immediately for instant response
  playNextLine();
}

function stopSimulation() {
  state.isSimulating = false;
  if (state.simulationTimeout) {
    clearTimeout(state.simulationTimeout);
    state.simulationTimeout = null;
  }
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({ type: "SPEAKING_STATUS", isSpeaking: false }, "*");
  }
  const btnStart = document.getElementById("btn-start-sim");
  const btnPause = document.getElementById("btn-pause-sim");
  if (btnStart) btnStart.style.display = "inline-flex";
  if (btnPause) btnPause.style.display = "none";

  const submitCard = document.getElementById("submit-proceed-card");
  const linesBadge = document.getElementById("submit-lines-badge");
  const topHandshakeBtn = document.getElementById("btn-goto-handshake");
  if (state.capturedTranscript && state.capturedTranscript.length > 0) {
    if (submitCard) submitCard.style.display = "block";
    if (linesBadge) linesBadge.innerText = `${state.capturedTranscript.length} lines ready`;
    if (topHandshakeBtn) {
      topHandshakeBtn.innerHTML = `Submit & Proceed →`;
      topHandshakeBtn.style.background = "var(--sage-accent)";
      topHandshakeBtn.style.color = "#FFFFFF";
      topHandshakeBtn.style.fontWeight = "600";
    }
  }
}

async function processIncomingLine(speaker, text, timestamp) {
  // Store line in transcript state
  state.capturedTranscript.push({ speaker, text, timestamp });
  document.getElementById("transcript-count").innerText = `${state.capturedTranscript.length} lines captured`;

  // Analyze text for delegation ambiguity
  let analysis = null;
  if (state.isServerConnected) {
    try {
      const res = await fetch(`${state.backendUrl}/api/intercept`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: text,
          context: state.capturedTranscript.map((t) => `${t.speaker}: ${t.text}`).slice(-4).join(" "),
          api_key: state.geminiKey
        })
      });
      if (res.ok) {
        analysis = await res.json();
      }
    } catch (e) {
      // Fallback to client heuristics
    }
  }

  if (!analysis) {
    analysis = clientIntercept(text);
  }

  // Forward to parent window (if running embedded in Web Companion)
  if (window.parent && window.parent !== window) {
    try {
      window.parent.postMessage({
        type: "CAPTIONS_MIRROR",
        speaker: speaker,
        text: text,
        timestamp: timestamp,
        is_ambiguous: Boolean(analysis && analysis.is_ambiguous),
        flags: (analysis && analysis.flags) ? analysis.flags : []
      }, "*");
    } catch (err) {
      console.warn("[The Mutual] postMessage mirror error:", err);
    }
  }

  // Render to Transcript Feed
  appendTranscriptLine(speaker, text, timestamp, analysis.is_ambiguous);

  // If ambiguity detected, play gentle intervention chime & render nudge card
  if (analysis.is_ambiguous && analysis.flags && analysis.flags.length > 0) {
    playInterventionChime();
    analysis.flags.forEach((flag) => {
      renderAlertCard(flag, text);
    });
  }
}

function appendTranscriptLine(speaker, text, timestamp, isVague) {
  const feed = document.getElementById("transcript-feed");
  // Remove placeholder if present
  if (feed.children.length === 1 && feed.children[0].innerText.includes("Click 'Start Simulation'")) {
    feed.innerHTML = "";
  }

  const entry = document.createElement("div");
  entry.className = "transcript-entry";
  entry.innerHTML = `
    <div style="display:flex; justify-content:space-between;">
      <span class="transcript-speaker">${escapeHtml(speaker)}</span>
      <span style="font-size:10px; color:var(--text-muted);">${escapeHtml(timestamp || "")}</span>
    </div>
    <div class="transcript-body ${isVague ? 'highlight-vague' : ''}">${escapeHtml(text)}</div>
  `;

  feed.appendChild(entry);
  feed.scrollTop = feed.scrollHeight;
}

function renderAlertCard(flag, originalStatement) {
  state.interceptorFlags.push(flag);
  document.getElementById("alert-counter").innerText = state.interceptorFlags.length;

  const container = document.getElementById("alerts-container");
  const card = document.createElement("div");
  card.className = "alert-card";

  const scriptId = `script_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

  card.innerHTML = `
    <div class="alert-header">
      <span class="badge badge-amber">
        ${escapeHtml(flag.category)}
      </span>
      <span style="font-size:11px; font-weight:600; color:var(--rust-text);">${escapeHtml(flag.risk_level || "High")} Risk</span>
    </div>

    <div class="alert-quote">
      "${escapeHtml(flag.detected_phrase || originalStatement)}"
    </div>

    <div class="alert-diagnosis">
      <strong>OB Diagnosis:</strong> ${escapeHtml(flag.ob_diagnosis)}
    </div>

    <div class="script-box">
      <div class="script-label">
        <span>Psychologically Safe Script:</span>
        <button class="btn btn-secondary btn-sm btn-copy-script" data-text="${escapeHtml(flag.suggested_script)}">
          Copy Script
        </button>
      </div>
      <div class="script-content" id="${scriptId}">
        "${escapeHtml(flag.suggested_script)}"
      </div>
    </div>
  `;

  // Attach copy event listener
  const copyBtn = card.querySelector(".btn-copy-script");
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(flag.suggested_script);
    copyBtn.innerText = "Copied";
    setTimeout(() => { copyBtn.innerText = "Copy Script"; }, 1800);
    showToast("Script copied. Ask this proactively to clarify!");
  });

  container.prepend(card);
}

function clientIntercept(text) {
  const flags = [];
  CLIENT_VAGUENESS_RULES.forEach((rule, idx) => {
    const match = text.match(rule.pattern);
    if (match) {
      flags.push({
        id: `client_flag_${idx}`,
        category: rule.category,
        detected_phrase: match[0],
        risk_level: rule.risk,
        ob_diagnosis: rule.diagnosis,
        suggested_script: rule.script
      });
    }
  });

  return {
    is_ambiguous: flags.length > 0,
    ambiguity_score: flags.length * 30,
    flags: flags
  };
}

// ============================================================================
// TAB 2: The Alignment Handshake (Micro Contract)
// ============================================================================

function initHandshake() {
  document.getElementById("btn-generate-contract").addEventListener("click", generateContractFromTranscript);
  document.getElementById("btn-load-ideal-contract").addEventListener("click", loadIdealScenarioContract);

  // Dual and Active Persona Sign Toggles
  const btnActiveSign = document.getElementById("btn-active-persona-sign");
  const btnQuickSwitch = document.getElementById("btn-quick-switch-persona");
  const btnSignEmp = document.getElementById("btn-toggle-sign-emp");
  const btnSignMgr = document.getElementById("btn-toggle-sign-mgr");

  if (btnSignEmp) {
    btnSignEmp.addEventListener("click", () => {
      state.employeeSigned = !state.employeeSigned;
      updateApprovalUI();
    });
  }

  if (btnSignMgr) {
    btnSignMgr.addEventListener("click", () => {
      state.managerSigned = !state.managerSigned;
      updateApprovalUI();
    });
  }

  if (btnActiveSign) {
    btnActiveSign.addEventListener("click", () => {
      if (state.activePersona === "neehal") {
        state.employeeSigned = !state.employeeSigned;
        showToast(state.employeeSigned ? "Handshake complete as Neehal." : "Handshake revoked by Neehal.");
      } else {
        state.managerSigned = !state.managerSigned;
        showToast(state.managerSigned ? "Handshake complete as Bhushith." : "Handshake revoked by Bhushith.");
      }
      updateApprovalUI();
    });
  }

  if (btnQuickSwitch) {
    btnQuickSwitch.addEventListener("click", () => {
      const next = state.activePersona === "neehal" ? "bhushith" : "neehal";
      setPersona(next);
      showToast(`Switched perspective to ${PERSONAS[next].name} (${PERSONAS[next].shortRole})`);
    });
  }

  // Export Tools
  document.getElementById("btn-copy-slack").addEventListener("click", copyContractSlack);

  // Initialize: if dialogue was already captured, synthesize; otherwise provide clean template
  if (state.capturedTranscript.length > 0) {
    generateContractFromTranscript();
  } else {
    state.currentContract = {
      title: "Delegation Alignment Micro Contract",
      clauses: [
        { num: 1, title: "Core Deliverable & Format", category: "deliverable", content: "Capture speech via live mic or paste briefing in Tab 1, then click 'Regenerate from Call'. (Or click 'Sample Contract' to view demo)", notes: "Format constraint" },
        { num: 2, title: "Hard Deadline & Milestone SLA", category: "timeline", content: "Agreed delivery cutoff and turnaround SLA will appear here.", notes: "Turnaround SLA" },
        { num: 3, title: "Definition of Done (DoD)", category: "dod", content: "Testable acceptance criteria translated from delegation directives.", notes: "Objective acceptance bar" },
        { num: 4, title: "Out-of-Scope Guardrails (Anti-Goals)", category: "guardrails", content: "Explicit boundary protections preventing uncredited scope creep.", notes: "Anti-scope protection" },
        { num: 5, title: "Sign Off Authority & Dependencies", category: "dependencies", content: "Single designated approver to eliminate bystander consensus stalls.", notes: "Diffuse review bypass" }
      ]
    };
    renderClauses(state.currentContract);
  }
}

async function generateContractFromTranscript() {
  const fullText = state.capturedTranscript.map((t) => `${t.speaker}: ${t.text}`).join(" ");
  if (!fullText || fullText.length < 15) {
    showToast("No active meeting dialogue recorded yet. Speak into the mic or paste a briefing in Tab 1.");
    return;
  }

  showToast("Synthesizing Micro Contract...");

  if (state.isServerConnected) {
    try {
      const res = await fetch(`${state.backendUrl}/api/handshake/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript: fullText, api_key: state.geminiKey })
      });
      if (res.ok) {
        state.currentContract = await res.json();
        renderClauses(state.currentContract);
        showToast("Micro Contract synthesized from actual meeting!");
        return;
      }
    } catch (e) {
      console.warn("[The Mutual] Backend generate error, using local engine:", e);
    }
  }

  // Dynamic client fallback: synthesize directly from fullText rather than static preset!
  state.currentContract = synthesizeClientDynamicContract(fullText);
  renderClauses(state.currentContract);
  showToast("Micro Contract synthesized using local behavioral engine.");
}

function synthesizeClientDynamicContract(transcript) {
  const textLower = transcript.toLowerCase();

  // Extract manager/speaker
  let manager = "Delegating Manager";
  const speakerMatch = transcript.match(/^([A-Za-z0-9\s\(\)]+?):/);
  if (speakerMatch && speakerMatch[1].length < 30) {
    manager = speakerMatch[1].trim();
  }

  // Deliverable
  let title = "Delegation Alignment Micro Contract";
  let deliverable = "Structured deliverable directly addressing the agreed briefing.";
  let formatNote = "Deliverable format explicit and agreed.";

  if (textLower.includes("deck") || textLower.includes("slide")) {
    title = "Executive Presentation Alignment Contract";
    deliverable = "A concise 5-to-7 slide deck (Google Slides) addressing the core review agenda.";
    formatNote = "Slide count bounded to prevent deck bloat.";
  } else if (textLower.includes("spec") || textLower.includes("checkout") || textLower.includes("feature") || textLower.includes("api") || textLower.includes("flow")) {
    title = "Technical Feature Specification Contract";
    deliverable = "A 2-to-3 page architectural RFC document detailing state transitions, error flows, and APIs.";
    formatNote = "Markdown specification in standard team repository.";
  } else if (textLower.includes("doc") || textLower.includes("report") || textLower.includes("write-up") || textLower.includes("summary")) {
    title = "Strategic Executive Brief Micro Contract";
    deliverable = "A structured 2-page executive summary highlighting findings and concrete recommendations.";
    formatNote = "Clean written summary with raw data in appendix.";
  } else if (textLower.includes("onboarding") || textLower.includes("guide") || textLower.includes("handbook")) {
    title = "Process & Operational Playbook Micro Contract";
    deliverable = "A step-by-step operational handbook with clear workflows and point-of-contact matrices.";
    formatNote = "Living document format with section owners.";
  }

  // Timeline
  let timeline = "Initial draft submitted in 3 business days by 3:00 PM; async feedback returned within 24 hours.";
  if (textLower.includes("sometime next week") || textLower.includes("next week")) {
    timeline = "Explicit cutoff: Wednesday at 3:00 PM (resolves 'sometime next week' ambiguity); written feedback returned by Thursday 11:00 AM.";
  } else if (textLower.includes("friday")) {
    timeline = "Hard deadline: Friday at 12:00 PM EST with mandatory 4-hour review window before week close.";
  } else if (textLower.includes("tomorrow")) {
    timeline = "Hard deadline: Tomorrow at 4:00 PM local time.";
  } else if (textLower.includes("asap") || textLower.includes("soon")) {
    timeline = "Explicit SLA: Initial draft submitted within 48 hours (resolving 'ASAP' urgency trap into measurable hours).";
  }

  // DoD
  let dodItems = [];
  if (textLower.includes("professional") || textLower.includes("pakka") || textLower.includes("clean") || textLower.includes("pop") || textLower.includes("magic") || textLower.includes("polish")) {
    dodItems.push("Formatted to official brand standards (resolving subjective 'clean/pop/professional')");
  }
  if (textLower.includes("benchmark") || textLower.includes("competitor")) {
    dodItems.push("Includes competitive benchmark parity matrix");
  }
  if (textLower.includes("pricing") || textLower.includes("cost") || textLower.includes("budget") || textLower.includes("finance")) {
    dodItems.push("Validated unit pricing & cost breakdown verified with finance");
  }
  if (textLower.includes("error") || textLower.includes("gateway") || textLower.includes("payment")) {
    dodItems.push("Explicit error-handling edge cases and retry mechanisms defined");
  }
  if (textLower.includes("kpi") || textLower.includes("metrics") || textLower.includes("rollout") || textLower.includes("pilot")) {
    dodItems.push("Validates core KPIs against telemetry baseline");
  }
  if (dodItems.length === 0) {
    dodItems = [
      "Addresses all core points raised in delegation briefing",
      "Includes concrete success metrics and next steps",
      "Preflight audited prior to final distribution"
    ];
  }
  const dod = "Verified criteria: " + dodItems.map((d, i) => `(${i+1}) ${d}`).join("; ") + ".";

  // Anti-goals
  let antiGoals = [];
  if (textLower.includes("international") || textLower.includes("tax")) antiGoals.push("international pricing models and multi-region tax calculations");
  if (textLower.includes("smart contract") || textLower.includes("blockchain")) antiGoals.push("experimental smart contracts");
  if (textLower.includes("adjust maadi") || textLower.includes("throw in") || textLower.includes("touch upon")) antiGoals.push("unbudgeted secondary requests mentioned casually");
  if (textLower.includes("video") || textLower.includes("animation")) antiGoals.push("custom video production");
  if (antiGoals.length === 0) {
    antiGoals.push("uncredited out-of-scope explorations and tangential side-quests");
  }
  const guardrails = "Strictly Out-of-Scope for V1: Do NOT build " + antiGoals.join(" or ") + ".";

  // Dependencies
  const dependencies = `Single designated primary approver is ${manager}. Feedback from broader team is advisory only.`;

  return {
    title: title,
    clauses: [
      { num: 1, title: "Core Deliverable & Format", category: "deliverable", content: deliverable, notes: formatNote },
      { num: 2, title: "Hard Deadline & Milestone SLA", category: "timeline", content: timeline, notes: "Turnaround SLA ensures momentum" },
      { num: 3, title: "Definition of Done (DoD)", category: "dod", content: dod, notes: "Objective acceptance bar" },
      { num: 4, title: "Out-of-Scope Guardrails (Anti-Goals)", category: "guardrails", content: guardrails, notes: "Anti-scope protection" },
      { num: 5, title: "Sign Off Authority & Dependencies", category: "dependencies", content: dependencies, notes: "Diffuse review bypass" }
    ]
  };
}

function loadIdealScenarioContract() {
  const selected = state.scenarios.find((s) => s.id === state.activeScenarioId) || state.scenarios[0];
  if (selected && selected.ideal_contract) {
    state.currentContract = JSON.parse(JSON.stringify(selected.ideal_contract));
  } else {
    // Default 5-Point Contract structure
    state.currentContract = {
      title: "Delegation Alignment Micro Contract",
      clauses: [
        { num: 1, title: "Core Deliverable & Format", category: "deliverable", content: "A 5-slide Google Slides deck built on the 2026 Executive Brand Template.", notes: "Format constraint" },
        { num: 2, title: "Hard Deadline & Milestone SLA", category: "timeline", content: "Draft delivered by Wednesday at 3:00 PM EST; feedback returned by Thursday 11:00 AM.", notes: "Turnaround SLA" },
        { num: 3, title: "Definition of Done (DoD)", category: "dod", content: "Includes: (1) Verified funnel KPIs, (2) Top 3 churn risks, (3) 90-day expansion milestones.", notes: "Objective acceptance bar" },
        { num: 4, title: "Out-of-Scope Guardrails (Anti-Goals)", category: "guardrails", content: "Explicitly exclude international pricing models and video demos to preserve sprint focus.", notes: "Anti-scope protection" },
        { num: 5, title: "Sign Off Authority & Dependencies", category: "dependencies", content: "Single approver is Marcus (VP). Sales feedback limited to Elena (Head of Enterprise).", notes: "Diffuse review bypass" }
      ]
    };
  }
  renderClauses(state.currentContract);
}

function renderClauses(contract) {
  const container = document.getElementById("clauses-list");
  container.innerHTML = "";

  (contract.clauses || []).forEach((clause) => {
    const el = document.createElement("div");
    el.className = "clause-item";
    el.innerHTML = `
      <div class="clause-header">
        <div class="clause-title-group">
          <div class="clause-num">${clause.num}</div>
          <span class="clause-title">${escapeHtml(clause.title)}</span>
        </div>
        <span class="badge badge-sage">Agreed</span>
      </div>
      <textarea class="clause-textarea" data-num="${clause.num}">${escapeHtml(clause.content)}</textarea>
      <div class="clause-note"><strong>OB Rationale:</strong> ${escapeHtml(clause.notes || "Explicit boundary setting")}</div>
    `;

    // Listen to manual edits
    const textarea = el.querySelector("textarea");
    textarea.addEventListener("input", (e) => {
      clause.content = e.target.value;
    });

    container.appendChild(el);
  });

  // Reset signatures for new contract
  state.employeeSigned = false;
  state.managerSigned = false;
  updateApprovalUI();
}

function updateApprovalUI() {
  const badgeEmp = document.getElementById("badge-party-emp");
  const partyStateEmp = document.getElementById("party-state-neehal");
  const badgeMgr = document.getElementById("badge-party-mgr");
  const partyStateMgr = document.getElementById("party-state-bhushith");
  const banner = document.getElementById("handshake-banner");
  const bannerTitle = document.getElementById("handshake-banner-title");
  const bannerSub = document.getElementById("handshake-banner-sub");
  const bannerBadge = document.getElementById("handshake-banner-badge");
  const bannerDot = document.getElementById("handshake-status-dot");
  const promptEl = document.getElementById("active-persona-action-prompt");
  const signBtn = document.getElementById("btn-active-persona-sign");
  const switchBtn = document.getElementById("btn-quick-switch-persona");

  // Neehal (Employee) state
  if (state.employeeSigned) {
    if (badgeEmp) {
      badgeEmp.className = "badge badge-sage badge-xs";
      badgeEmp.innerText = "Handshaked";
    }
    if (partyStateEmp) partyStateEmp.innerText = "Handshaked";
  } else {
    if (badgeEmp) {
      badgeEmp.className = "badge badge-amber badge-xs";
      badgeEmp.innerText = "Pending";
    }
    if (partyStateEmp) partyStateEmp.innerText = "Pending";
  }

  // Bhushith (Manager) state
  if (state.managerSigned) {
    if (badgeMgr) {
      badgeMgr.className = "badge badge-sage badge-xs";
      badgeMgr.innerText = "Handshaked";
    }
    if (partyStateMgr) partyStateMgr.innerText = "Handshaked";
  } else {
    if (badgeMgr) {
      badgeMgr.className = "badge badge-amber badge-xs";
      badgeMgr.innerText = "Pending";
    }
    if (partyStateMgr) partyStateMgr.innerText = "Pending";
  }

  // Contextual controls for active persona
  const isNeehal = state.activePersona === "neehal";

  if (isNeehal) {
    if (signBtn) {
      if (state.employeeSigned) {
        signBtn.innerText = "Revoke Handshake (Neehal)";
        signBtn.className = "btn btn-secondary btn-handshake-action";
      } else {
        signBtn.innerText = "🤝 Handshake as Neehal";
        signBtn.className = "btn btn-sage btn-handshake-action";
      }
    }
    if (promptEl) {
      if (state.employeeSigned && state.managerSigned) {
        promptEl.innerHTML = `Mutual handshake secured! Both <strong>Neehal</strong> and <strong>Bhushith</strong> are aligned.`;
      } else if (state.employeeSigned) {
        promptEl.innerHTML = `Handshaked as <strong>Neehal</strong>. Awaiting <strong>Bhushith</strong> (Manager) handshake.`;
      } else {
        promptEl.innerHTML = `Active as <strong>Neehal</strong> (Employee). Review the clauses below and handshake.`;
      }
    }
    if (switchBtn) {
      switchBtn.innerText = "Switch to Bhushith POV →";
    }
  } else {
    // Bhushith (Manager)
    if (signBtn) {
      if (state.managerSigned) {
        signBtn.innerText = "Revoke Handshake (Bhushith)";
        signBtn.className = "btn btn-secondary btn-handshake-action";
      } else {
        signBtn.innerText = "🤝 Handshake as Bhushith";
        signBtn.className = "btn btn-sage btn-handshake-action";
      }
    }
    if (promptEl) {
      if (state.employeeSigned && state.managerSigned) {
        promptEl.innerHTML = `Mutual handshake secured! Both <strong>Bhushith</strong> and <strong>Neehal</strong> are aligned.`;
      } else if (state.managerSigned) {
        promptEl.innerHTML = `Handshaked as <strong>Bhushith</strong>. Awaiting <strong>Neehal</strong> (Employee) handshake.`;
      } else {
        promptEl.innerHTML = `Active as <strong>Bhushith</strong> (Manager). Review the clauses below and handshake.`;
      }
    }
    if (switchBtn) {
      switchBtn.innerText = "Switch to Neehal POV →";
    }
  }

  // Overall Handshake status banner
  if (state.employeeSigned && state.managerSigned) {
    if (banner) banner.className = "handshake-bar sealed";
    if (bannerTitle) bannerTitle.innerText = "Handshake Sealed & Locked";
    if (bannerSub) bannerSub.innerText = "Dual handshakes recorded (Neehal & Bhushith). Work can now proceed.";
    if (bannerBadge) {
      bannerBadge.className = "badge badge-sage badge-sm";
      bannerBadge.innerText = "Locked (2/2)";
    }
    if (bannerDot) {
      bannerDot.style.background = "#2D6A4F";
      bannerDot.className = "pulse-dot-green";
    }
  } else {
    if (banner) banner.className = "handshake-bar";
    const signedCount = (state.employeeSigned ? 1 : 0) + (state.managerSigned ? 1 : 0);
    if (signedCount === 1) {
      if (bannerTitle) bannerTitle.innerText = "Handshake In Progress";
      if (bannerSub) bannerSub.innerText = "1 of 2 parties handshaked. Awaiting second party.";
      if (bannerBadge) {
        bannerBadge.className = "badge badge-amber badge-sm";
        bannerBadge.innerText = "1 / 2 Handshaked";
      }
      if (bannerDot) {
        bannerDot.style.background = "#D97706";
        bannerDot.className = "status-dot";
      }
    } else {
      if (bannerTitle) bannerTitle.innerText = "Handshake Pending";
      if (bannerSub) bannerSub.innerText = "Awaiting mutual handshake before work begins.";
      if (bannerBadge) {
        bannerBadge.className = "badge badge-amber badge-sm";
        bannerBadge.innerText = "0 / 2 Handshaked";
      }
      if (bannerDot) {
        bannerDot.style.background = "#A8A29E";
        bannerDot.className = "status-dot";
      }
    }
  }
}

function copyContractSlack() {
  if (!state.currentContract) return;

  let text = `*The Mutual: Delegation Alignment Handshake*\n`;
  text += `_Agreement between Delegator and Executor before sprint start_\n\n`;

  (state.currentContract.clauses || []).forEach((c) => {
    text += `*${c.num}. ${c.title}*\n${c.content}\n\n`;
  });

  text += `*Sign Off Status*: ${state.employeeSigned && state.managerSigned ? "Approved by Both Parties" : "Pending Sign Off"}\n`;

  navigator.clipboard.writeText(text);
  showToast("Recap copied to clipboard for Slack / Email!");
}

// ============================================================================
// TAB 3: Preflight Deliverable Auditor
// ============================================================================

function initPreflight() {
  const btnPullActive = document.getElementById("btn-pull-active-tab");
  const btnSampleStrong = document.getElementById("btn-sample-strong");
  const btnSampleFlawed = document.getElementById("btn-sample-flawed");
  const btnRunAudit = document.getElementById("btn-run-audit");
  const deliverableInput = document.getElementById("deliverable-input");

  btnSampleStrong.addEventListener("click", () => {
    if (state.sampleDeliverables.strong) {
      deliverableInput.value = state.sampleDeliverables.strong;
      showToast("Loaded high-alignment sample draft.");
    }
  });

  btnSampleFlawed.addEventListener("click", () => {
    if (state.sampleDeliverables.flawed) {
      deliverableInput.value = state.sampleDeliverables.flawed;
      showToast("Loaded flawed draft with scope creep.");
    }
  });

  btnPullActive.addEventListener("click", () => {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: "GET_ACTIVE_PAGE_TEXT" }, (response) => {
        if (response && response.text) {
          deliverableInput.value = response.text;
          showToast("Extracted content from active tab.");
        } else {
          showToast("Could not extract text. Please copy-paste your draft directly.");
        }
      });
    } else {
      showToast("Tab extraction active in Chrome extension mode. Paste draft manually for web test.");
    }
  });

  btnRunAudit.addEventListener("click", executePreflightAudit);
}

async function executePreflightAudit() {
  const text = document.getElementById("deliverable-input").value.trim();
  if (!text) {
    showToast("Please paste draft content or click 'Strong Sample' to audit.");
    return;
  }

  if (!state.currentContract) {
    loadIdealScenarioContract();
  }

  showToast("Auditing draft against agreed 5-point contract...");

  let result = null;
  if (state.isServerConnected) {
    try {
      const res = await fetch(`${state.backendUrl}/api/preflight/audit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contract: state.currentContract,
          deliverable_text: text,
          api_key: state.geminiKey
        })
      });
      if (res.ok) {
        result = await res.json();
      }
    } catch (e) {
      // fallback
    }
  }

  if (!result) {
    result = clientPreflightAudit(state.currentContract, text);
  }

  renderAuditResults(result);
}

function renderAuditResults(result) {
  const card = document.getElementById("audit-results-card");
  card.style.display = "flex";

  const scoreNum = document.getElementById("audit-score-num");
  const verdictText = document.getElementById("audit-verdict-text");
  const verdictBadge = document.getElementById("audit-verdict-badge");
  const checklist = document.getElementById("audit-checklist");
  const remediesList = document.getElementById("audit-remedies-list");

  scoreNum.innerText = `${result.alignment_score}%`;
  verdictText.innerText = result.verdict;

  if (result.alignment_score >= 85) {
    verdictBadge.className = "badge badge-sage";
    verdictBadge.innerText = "Passed";
  } else if (result.alignment_score >= 60) {
    verdictBadge.className = "badge badge-amber";
    verdictBadge.innerText = "Adjustments Needed";
  } else {
    verdictBadge.className = "badge badge-rust";
    verdictBadge.innerText = "High Risk";
  }

  checklist.innerHTML = "";
  (result.evaluations || []).forEach((item) => {
    const el = document.createElement("div");
    el.className = `audit-check-item ${item.status}`;

    let statusClass = "badge-sage";
    if (item.status === "warning") {
      statusClass = "badge-amber";
    } else if (item.status === "missing") {
      statusClass = "badge-rust";
    }

    el.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="font-size:12px; font-weight:600; color:var(--text-primary);">
          Clause ${item.num}: ${escapeHtml(item.title)}
        </span>
        <span class="badge ${statusClass}">${item.status.toUpperCase()}</span>
      </div>
      <div style="font-size:11.5px; color:var(--text-secondary); line-height:1.4;">
        ${escapeHtml(item.commentary)}
      </div>
    `;

    checklist.appendChild(el);
  });

  remediesList.innerHTML = "";
  (result.remedies || []).forEach((rem) => {
    const li = document.createElement("li");
    li.textContent = rem;
    remediesList.appendChild(li);
  });

  card.scrollIntoView({ behavior: "smooth" });
}

function clientPreflightAudit(contract, text) {
  const clauses = contract.clauses || [];
  const textLower = text.toLowerCase();
  let passedCount = 0;
  const evaluations = [];

  const scopeCreepSignals = ["blockchain", "international", "emea", "asia", "tax laws", "12 pages", "smart contract"];
  const hasScopeCreep = scopeCreepSignals.some((sig) => textLower.includes(sig));
  const isExplicitlyExcluded = scopeCreepSignals.some(
    (sig) => textLower.includes(sig) && (textLower.includes("exclud") || textLower.includes("not included") || textLower.includes("out-of-scope"))
  );

  clauses.forEach((c) => {
    const content = (c.content || "").toLowerCase();
    const title = c.title || "";
    const category = c.category || "";

    const words = content.match(/\b[a-zA-Z]{4,}\b/g) || [];
    const stopwords = new Set(["with", "this", "that", "from", "have", "must", "deck", "presentation", "slides", "built"]);
    const filterWords = words.filter((w) => !stopwords.has(w));
    const matches = filterWords.filter((w) => textLower.includes(w));
    const ratio = matches.length / Math.max(filterWords.length, 1);

    let status = "missing";
    let commentary = `No clear evidence found matching agreed terms: "${c.content}"`;

    if (category === "guardrails") {
      if (isExplicitlyExcluded) {
        status = "passed";
        passedCount += 1;
        commentary = "Out-of-scope boundaries respected: explicitly confirmed exclusion of anti-goals.";
      } else if (hasScopeCreep) {
        status = "missing";
        commentary = "Scope violation: Draft contains elements explicitly marked as out-of-scope in Micro Contract.";
      } else if (textLower.includes("out-of-scope") || textLower.includes("excluded") || ratio >= 0.25) {
        status = "passed";
        passedCount += 1;
        commentary = "Out-of-scope boundaries respected and explicitly documented.";
      } else {
        status = "warning";
        passedCount += 0.5;
        commentary = "No explicit disclaimer found confirming that out-of-scope items were excluded.";
      }
    } else if (category === "dependencies") {
      if ((textLower.includes("approv") || textLower.includes("signed off") || textLower.includes("reviewed")) && ratio >= 0.15) {
        status = "passed";
        passedCount += 1;
        commentary = "Designated approver / stakeholder check-in verified in draft header.";
      } else if (ratio >= 0.3) {
        status = "passed";
        passedCount += 1;
        commentary = `Verified alignment with ${title}.`;
      } else {
        status = "missing";
        commentary = `Approver verification missing. Agreed clause: "${c.content}".`;
      }
    } else if (category === "dod") {
      if ((textLower.includes("definition of done") || textLower.includes("kpi") || textLower.includes("checklist")) && ratio >= 0.2) {
        status = "passed";
        passedCount += 1;
        commentary = "Definition of Done requirements validated against draft content.";
      } else if (ratio >= 0.35) {
        status = "passed";
        passedCount += 1;
        commentary = `Evidence of "${title}" verified in draft content.`;
      } else if (ratio >= 0.15) {
        status = "warning";
        passedCount += 0.5;
        commentary = `Partial fulfillment for ${title}. Metric evidence is vague.`;
      } else {
        status = "missing";
        commentary = `Missing DoD metrics. Agreed clause: "${c.content}".`;
      }
    } else {
      if (ratio >= 0.3) {
        status = "passed";
        passedCount += 1;
        commentary = `Verified compliance with ${title}.`;
      } else if (ratio >= 0.12) {
        status = "warning";
        passedCount += 0.5;
        commentary = `Partial evidence found for ${title}. Recommend explicit callout.`;
      } else {
        status = "missing";
        commentary = `No clear evidence matching agreed terms: "${c.content}".`;
      }
    }

    evaluations.push({
      num: c.num,
      title: title,
      status: status,
      commentary: commentary
    });
  });

  const score = Math.round((passedCount / Math.max(clauses.length, 1)) * 100);
  let verdict = "Ready to Submit";
  if (score < 50) {
    verdict = "High Risk of Rejection";
  } else if (score < 80) {
    verdict = "Minor Adjustments Recommended";
  }

  return {
    alignment_score: score,
    verdict: verdict,
    evaluations: evaluations,
    remedies: [
      "Confirm that out-of-scope boundaries are explicitly stated in your overview.",
      "Check that the designated single approver is listed on the deliverable header.",
      "Ensure all Definition of Done criteria are present and measurable."
    ]
  };
}

// ============================================================================
// TAB 4: Settings & Configuration
// ============================================================================

function initSettings() {
  const btnSave = document.getElementById("btn-save-settings");
  const btnTest = document.getElementById("btn-test-connection");
  const urlInput = document.getElementById("setting-backend-url");
  const keyInput = document.getElementById("setting-gemini-key");
  const feedback = document.getElementById("settings-status-feedback");
  const providerSelect = document.getElementById("setting-llm-provider");
  const chimeToggle = document.getElementById("setting-chime-toggle");
  const autoDodToggle = document.getElementById("setting-auto-dod");

  if (providerSelect) {
    const savedProvider = localStorage.getItem("mutual_llm_provider") || "gemini-3.5-flash-lite";
    providerSelect.value = savedProvider;
    providerSelect.addEventListener("change", () => {
      localStorage.setItem("mutual_llm_provider", providerSelect.value);
      showToast(`AI engine set to ${providerSelect.options[providerSelect.selectedIndex].text.split("(")[0].trim()}`);
    });
  }

  if (chimeToggle) {
    const savedChime = localStorage.getItem("mutual_chime_enabled");
    if (savedChime !== null) chimeToggle.checked = savedChime === "true";
    chimeToggle.addEventListener("change", () => {
      localStorage.setItem("mutual_chime_enabled", chimeToggle.checked);
      showToast(chimeToggle.checked ? "Chime alerts enabled" : "Chimes muted");
    });
  }

  if (autoDodToggle) {
    const savedDod = localStorage.getItem("mutual_auto_dod");
    if (savedDod !== null) autoDodToggle.checked = savedDod === "true";
    autoDodToggle.addEventListener("change", () => {
      localStorage.setItem("mutual_auto_dod", autoDodToggle.checked);
    });
  }

  // Check if backend already has GEMINI_API_KEY loaded
  try {
    fetch(`${state.backendUrl}/api/settings`)
      .then(r => r.json())
      .then(data => {
        if (data && data.has_key && keyInput && !keyInput.value) {
          keyInput.placeholder = `Active on backend (${data.model || "gemini-3.5-flash-lite"})`;
        }
      })
      .catch(() => {});
  } catch (e) {}

  if (!btnSave) return;

  btnSave.addEventListener("click", async () => {
    state.backendUrl = urlInput.value.trim() || "http://localhost:8000";
    const enteredKey = keyInput.value.trim();
    if (enteredKey) {
      state.geminiKey = enteredKey;
    }

    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({
        backendUrl: state.backendUrl,
        geminiKey: state.geminiKey
      });
    } else {
      localStorage.setItem("mutual_backend_url", state.backendUrl);
      if (state.geminiKey) localStorage.setItem("mutual_gemini_key", state.geminiKey);
    }

    if (feedback) feedback.innerHTML = `<span style="color:#78716C;">Saving & validating key...</span>`;

    // Sync to backend if connected
    try {
      const payload = state.geminiKey ? { api_key: state.geminiKey } : {};
      const res = await fetch(`${state.backendUrl}/api/settings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.test_result && data.test_result.valid) {
          if (feedback) feedback.innerHTML = `<span style="color:var(--sage-text); font-weight:600;">Connected to Gemini (${escapeHtml(data.test_result.model)})</span>`;
          showToast(`Gemini active using model ${data.test_result.model}!`);
        } else if (data.test_result && data.test_result.error) {
          if (feedback) feedback.innerHTML = `<span style="color:#DC2626;">${escapeHtml(data.test_result.error)}</span>`;
          showToast("Settings saved, but Gemini key returned an error.");
        } else {
          if (feedback) feedback.innerHTML = `<span style="color:var(--sage-text);">Configuration saved</span>`;
          showToast("Settings saved successfully.");
        }
      }
    } catch (e) {
      if (feedback) feedback.innerHTML = `<span style="color:#78716C;">Saved locally (backend unreachable)</span>`;
      showToast("Settings saved locally.");
    }

    checkBackendHealth();
  });

  btnTest.addEventListener("click", async () => {
    state.backendUrl = urlInput.value.trim() || "http://localhost:8000";
    const enteredKey = keyInput.value.trim();
    if (enteredKey) {
      state.geminiKey = enteredKey;
    }
    if (feedback) feedback.innerHTML = `<span style="color:#78716C;">Testing connection...</span>`;
    showToast("Testing backend & Gemini connection...");

    try {
      const payload = state.geminiKey ? { api_key: state.geminiKey } : {};
      const res = await fetch(`${state.backendUrl}/api/settings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.test_result && data.test_result.valid) {
          if (feedback) feedback.innerHTML = `<span style="color:var(--sage-text); font-weight:600;">Gemini Online (${escapeHtml(data.test_result.model)})</span>`;
          showToast(`Verified! Gemini ${data.test_result.model} is operational.`);
        } else {
          const errMsg = (data.test_result && data.test_result.error) || "Local engine active (no Gemini key)";
          if (feedback) feedback.innerHTML = `<span style="color:#B45309;">${escapeHtml(errMsg)}</span>`;
          showToast(errMsg);
        }
      }
    } catch (e) {
      if (feedback) feedback.innerHTML = `<span style="color:#DC2626;">Backend offline at ${escapeHtml(state.backendUrl)}</span>`;
      showToast("Cannot connect to backend server.");
    }

    await checkBackendHealth();
  });
}

// ============================================================================
// Chrome Extension Event Listeners
// ============================================================================

function listenToExtensionEvents() {
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {

      // ── Live captions forwarded from any meeting platform content script ──
      if ((message.type === "CAPTIONS_CHUNK" || message.type === "CAPTIONS_CHUNK_LIVE") && message.payload) {
        const { speaker, text, timestamp } = message.payload;
        if (text) {
          const t = text.toLowerCase();
          if (t.includes("looking to create a workspace") || t.includes("create a new workspace") || t.includes("workspace instead")) {
            return;
          }
        }
        processIncomingLine(speaker || "Participant", text, timestamp);
      }

      // ── Speech result from the offscreen SpeechRecognition bridge ──────────
      else if (message.type === "SPEECH_RESULT") {
        handleSpeechResult(message.transcript, message.isFinal);
        // Hide interim box when final
        if (message.isFinal) {
          const interimBox = document.getElementById("live-interim-box");
          if (interimBox) interimBox.style.display = "none";
        }
      }

      // ── Offscreen SpeechRecognition started successfully ──────────────────
      else if (message.type === "SPEECH_STATUS" && message.status === "started") {
        handleSpeechStarted();
      }

      // ── Offscreen SpeechRecognition stopped ───────────────────────────────
      else if (message.type === "SPEECH_STATUS" && message.status === "stopped") {
        if (!state.isLiveMicListening) {
          updateMicStoppedUI();
        }
      }

      // ── Offscreen error (not-allowed, no-speech, etc.) ────────────────────
      else if (message.type === "SPEECH_ERROR") {
        handleSpeechError(message.error);
      }

      // ── Microphone permission granted from permission.html tab ─────
      else if (message.type === "MIC_PERMISSION_GRANTED") {
        state.micAuthorized = true;
        showToast("Microphone permission granted! Starting live listening…");
        const dot  = document.getElementById("mic-status-dot");
        const desc = document.getElementById("mic-status-description");
        if (dot)  dot.className = "pulse-dot-green";
        if (desc) desc.innerText = "Microphone Authorized! Starting live speech listener…";
        setTimeout(() => { startLiveMicrophone(); }, 300);
      }
    });
  }
}

// ============================================================================
// Toast & Utility Helpers
// ============================================================================

function showToast(msg) {
  const container = document.getElementById("toast-container");
  if (!container) return;

  // Prevent duplicate toast spamming
  const existing = Array.from(container.querySelectorAll(".toast"));
  if (existing.some((t) => t.innerText === msg)) {
    return;
  }

  // Keep max 2 toasts visible at any time
  while (container.children.length >= 2) {
    container.removeChild(container.firstChild);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerText = msg;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.2s ease";
    setTimeout(() => { toast.remove(); }, 200);
  }, 2400);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Expose on window for parent frame integration
if (typeof window !== "undefined") {
  window.state = state;
  window.startSimulation = startSimulation;
  window.stopSimulation = stopSimulation;

  // Listen for Option+M inside the sidepanel iframe and relay to parent drawer/tab
  window.addEventListener("keydown", (e) => {
    const isM = (e.code === "KeyM" || e.key === "m" || e.key === "M" || e.key === "µ" || e.key === "Âµ");
    if (isM && (e.altKey || (e.metaKey && e.shiftKey) || (e.ctrlKey && e.shiftKey))) {
      e.preventDefault();
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: "THE_MUTUAL_TOGGLE_DRAWER" }, "*");
      }
    }
  }, true);
}
