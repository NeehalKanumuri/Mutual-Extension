/**
 * The Mutual - Background Service Worker (Manifest V3)
 *
 * Responsibilities:
 *  1. Open side panel on extension icon click
 *  2. Manage the Offscreen document for microphone / SpeechRecognition
 *  3. Relay caption chunks from content scripts → storage + side panel
 *  4. Relay speech results from offscreen → side panel
 *  5. Serve page-text extraction requests from the side panel
 */

// ── Setup ────────────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .catch((e) => console.warn("[The Mutual] sidePanel behaviour:", e));
  }
  console.log("[The Mutual] Extension installed / updated.");
});

// Ensure panel opens on action click across worker wakeups
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch(() => {});
}

// Option+M / Alt+M Command listener
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener((command) => {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.sidePanel.open({ tabId: tabs[0].id }).catch((e) => {
            console.warn("[The Mutual] Could not open side panel via command:", e);
          });
        }
      });
    }
  });
}

// ── Offscreen document management ────────────────────────────────────────────

const OFFSCREEN_URL = chrome.runtime.getURL("offscreen.html");
const OFFSCREEN_REASONS = ["USER_MEDIA"]; // Needed for mic access

async function ensureOffscreen() {
  // Chrome 116+ API
  if (chrome.offscreen) {
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [OFFSCREEN_URL]
    }).catch(() => []);

    if (existingContexts.length === 0) {
      await chrome.offscreen.createDocument({
        url:    OFFSCREEN_URL,
        reasons: OFFSCREEN_REASONS,
        justification: "Speech recognition requires microphone access via USER_MEDIA."
      });
      console.log("[The Mutual] Offscreen document created.");
    }
  }
}

async function closeOffscreen() {
  if (chrome.offscreen) {
    await chrome.offscreen.closeDocument().catch(() => {});
    console.log("[The Mutual] Offscreen document closed.");
  }
}

// ── Message routing ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // ── Open Side Panel request from content script / badge / shortcut ─────────
  if (message.type === "OPEN_SIDEPANEL") {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      const tabId = (sender && sender.tab && sender.tab.id) ? sender.tab.id : null;
      if (tabId) {
        chrome.sidePanel.open({ tabId }).catch((e) => console.warn("[The Mutual] sidePanel.open failed:", e));
      } else {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs[0] && tabs[0].id) {
            chrome.sidePanel.open({ tabId: tabs[0].id }).catch(() => {});
          }
        });
      }
    }
    sendResponse({ status: "ok" });
    return true;
  }

  // ── Captions from content scripts (Meet, Zoom, Teams, Slack …) ───────────
  if (message.type === "CAPTIONS_CHUNK") {
    if (message.payload && message.payload.text) {
      const t = message.payload.text.toLowerCase();
      if (t.includes("looking to create a workspace") || t.includes("create a new workspace") || t.includes("workspace instead")) {
        sendResponse({ status: "ignored_boilerplate" });
        return true;
      }
    }

    // Persist to local storage (ring-buffer of 100 entries)
    chrome.storage.local.get(["session_transcript"], (res) => {
      const existing = (res.session_transcript || []).filter(item => {
        if (!item || !item.text) return false;
        const it = item.text.toLowerCase();
        return !it.includes("looking to create a workspace") && !it.includes("workspace instead");
      });
      const updated  = [...existing, message.payload];
      chrome.storage.local.set({ session_transcript: updated.slice(-100) });
    });

    // Also forward live to any open side panel
    chrome.runtime.sendMessage({ type: "CAPTIONS_CHUNK_LIVE", payload: message.payload })
      .catch(() => {}); // Side panel may not be open yet

    sendResponse({ status: "acknowledged" });
    return true;
  }

  // ── Side panel: start microphone via offscreen ────────────────────────────
  if (message.type === "START_MIC") {
    ensureOffscreen().then(() => {
      chrome.runtime.sendMessage({
        type:   "START_RECOGNITION",
        target: "offscreen",
        lang:   message.lang || "en-IN"
      }).catch(() => {});
    });
    sendResponse({ status: "ok" });
    return true;
  }

  // ── Side panel: stop microphone ───────────────────────────────────────────
  if (message.type === "STOP_MIC") {
    chrome.runtime.sendMessage({
      type:   "STOP_RECOGNITION",
      target: "offscreen"
    }).catch(() => {});
    sendResponse({ status: "ok" });
    return true;
  }

  // ── Offscreen → side panel: speech results ────────────────────────────────
  if (message.type === "SPEECH_RESULT") {
    chrome.runtime.sendMessage({ type: "SPEECH_RESULT", transcript: message.transcript, isFinal: message.isFinal })
      .catch(() => {});
    return false;
  }

  if (message.type === "SPEECH_ERROR") {
    chrome.runtime.sendMessage({ type: "SPEECH_ERROR", error: message.error })
      .catch(() => {});
    return false;
  }

  if (message.type === "SPEECH_STATUS") {
    chrome.runtime.sendMessage({ type: "SPEECH_STATUS", status: message.status })
      .catch(() => {});
    return false;
  }

  // ── Page text extraction (for Pre-Flight) ─────────────────────────────────
  if (message.type === "GET_ACTIVE_PAGE_TEXT") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) {
        sendResponse({ text: "" });
        return;
      }
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const selection = window.getSelection()?.toString().trim() || "";
          if (selection.length > 20) return selection;

          const docBody =
            document.querySelector(".kix-page-content")        // Google Docs
            || document.querySelector(".notion-page-content")   // Notion
            || document.querySelector("[role='main']")          // Gmail / generic
            || document.body;
          return docBody ? (docBody.innerText || "") : "";
        }
      }, (results) => {
        if (chrome.runtime.lastError || !results || !results[0]) {
          sendResponse({ text: "" });
        } else {
          sendResponse({ text: results[0].result || "" });
        }
      });
    });
    return true; // async response
  }
});
